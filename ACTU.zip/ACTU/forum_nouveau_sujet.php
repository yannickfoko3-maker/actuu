<?php
/**
 * ACTU EVENTS MAGAZINE - Créer un nouveau sujet de forum
 */
$currentPage = 'forum';
$pageTitle = 'Nouveau sujet';
require_once __DIR__ . '/config.php';

if (!isLoggedIn()) {
    setFlash('error', 'Connectez-vous pour créer un sujet.');
    redirect(SITE_URL . '/connexion.php');
}

$forumId = intval($_GET['forum'] ?? 0);
$forums = $pdo->query("SELECT id, titre FROM forums WHERE statut = 'ouvert' ORDER BY titre")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }

    $titre = trim($_POST['titre'] ?? '');
    $contenu = trim($_POST['contenu'] ?? '');
    $selectedForum = intval($_POST['forum_id'] ?? 0);

    $errors = [];
    if (empty($titre)) $errors[] = 'Le titre est obligatoire.';
    if (empty($contenu)) $errors[] = 'Le contenu est obligatoire.';
    if (!$selectedForum) $errors[] = 'Veuillez choisir un forum.';

    if (empty($errors)) {
        $slug = generateSlug($titre) . '-' . uniqid();
        $stmt = $pdo->prepare("INSERT INTO sujets_forum (titre, slug, contenu, forum_id, auteur_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$titre, $slug, sanitize($contenu), $selectedForum, $_SESSION['user_id']]);
        $sujetId = $pdo->lastInsertId();

        // Upload médias
        if (!empty($_FILES['medias']['name'][0])) {
            $files = $_FILES['medias'];
            for ($i = 0; $i < min(count($files['name']), 5); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $file = [
                        'name' => $files['name'][$i], 'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i], 'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    $result = uploadFile($file, 'forum');
                    if ($result['success']) {
                        $pdo->prepare("INSERT INTO medias_forum (nom_fichier, chemin, type_mime, taille, sujet_id, uploadeur_id) VALUES (?, ?, ?, ?, ?, ?)")
                            ->execute([$files['name'][$i], $result['path'], $result['mime'], $result['size'], $sujetId, $_SESSION['user_id']]);
                    }
                }
            }
        }

        $pdo->prepare("UPDATE forums SET nb_sujets = nb_sujets + 1, date_dernier_message = NOW() WHERE id = ?")->execute([$selectedForum]);
        setFlash('success', 'Sujet créé avec succès !');
        redirect(SITE_URL . '/forum_discussion.php?id=' . $sujetId);
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<section style="padding-top: 100px; padding-bottom: var(--spacing-3xl);">
    <div class="container" style="max-width: 800px;">
        <h1 style="font-family: var(--font-serif); font-size: 1.8rem; margin-bottom: var(--spacing-xl);">
            <i class="fas fa-plus-circle text-accent"></i> Nouveau sujet
        </h1>

        <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <div><?php foreach ($errors as $e) echo '<p>' . sanitize($e) . '</p>'; ?></div>
        </div>
        <?php endif; ?>

        <div class="card" style="padding: var(--spacing-xl);">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                <div class="form-group">
                    <label class="form-label">Forum *</label>
                    <select name="forum_id" class="form-control" required>
                        <option value="">-- Choisir un forum --</option>
                        <?php foreach ($forums as $f): ?>
                        <option value="<?= $f['id'] ?>" <?= $forumId == $f['id'] ? 'selected' : '' ?>>
                            <?= sanitize($f['titre']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Titre du sujet *</label>
                    <input type="text" name="titre" class="form-control" placeholder="Titre de votre sujet"
                           value="<?= sanitize($titre ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Contenu *</label>
                    <div class="editor-toolbar">
                        <button type="button" onclick="formatText('bold')" title="Gras"><i class="fas fa-bold"></i></button>
                        <button type="button" onclick="formatText('italic')" title="Italique"><i class="fas fa-italic"></i></button>
                        <button type="button" onclick="formatText('underline')" title="Souligné"><i class="fas fa-underline"></i></button>
                        <span class="separator"></span>
                        <button type="button" onclick="formatText('insertUnorderedList')"><i class="fas fa-list-ul"></i></button>
                    </div>
                    <textarea name="contenu" id="contenu" class="form-control" 
                              style="border-radius: 0 0 var(--radius-sm) var(--radius-sm); min-height: 200px;"
                              placeholder="Décrivez votre sujet en détail..." required><?= sanitize($contenu ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Médias (images, vidéos - max 5)</label>
                    <div class="upload-zone" onclick="document.getElementById('mediaInput').click();">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Cliquez ou glissez vos fichiers ici</p>
                        <p class="upload-formats">JPG, PNG, GIF, WebP, MP4, WebM • Max 10 Mo/fichier</p>
                    </div>
                    <input type="file" name="medias[]" id="mediaInput" multiple accept="image/*,video/*" style="display: none;">
                    <div id="previewZone" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;"></div>
                </div>

                <div style="display: flex; gap: var(--spacing-md);">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane"></i> Publier le sujet
                    </button>
                    <a href="<?= SITE_URL ?>/forum.php" class="btn btn-secondary btn-lg">Annuler</a>
                </div>
            </form>
        </div>
    </div>
</section>

<?php
$extraJS = '<script>
function formatText(cmd) {
    const t = document.getElementById("contenu");
    const s = t.selectionStart, e = t.selectionEnd, sel = t.value.substring(s, e);
    let w = "";
    if (cmd === "bold") w = "**";
    else if (cmd === "italic") w = "*";
    else if (cmd === "underline") w = "__";
    if (w) { t.value = t.value.substring(0, s) + w + sel + w + t.value.substring(e); t.focus(); }
}
document.getElementById("mediaInput").addEventListener("change", function() {
    const pz = document.getElementById("previewZone"); pz.innerHTML = "";
    Array.from(this.files).forEach(f => {
        const d = document.createElement("div");
        d.style.cssText = "width:80px;height:80px;border-radius:8px;overflow:hidden;border:1px solid var(--border-color);position:relative;";
        if (f.type.startsWith("image/")) { const i = document.createElement("img"); i.src = URL.createObjectURL(f); i.style.cssText = "width:100%;height:100%;object-fit:cover;"; d.appendChild(i); }
        else { d.innerHTML = "<div style=\"display:flex;align-items:center;justify-content:center;width:100%;height:100%;background:var(--bg-secondary);\"><i class=\"fas fa-video\" style=\"color:var(--accent-primary);\"></i></div>"; }
        pz.appendChild(d);
    });
});
</script>';
require_once __DIR__ . '/includes/footer.php';
?>
