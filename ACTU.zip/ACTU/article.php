<?php
/**
 * ACTU EVENTS MAGAZINE - Page article individuel
 */
require_once __DIR__ . '/config.php';

$slug = $_GET['slug'] ?? '';
if (empty($slug)) { redirect(SITE_URL . '/'); }

// Récupérer l'article
$stmt = $pdo->prepare("
    SELECT a.*, r.nom AS rubrique_nom, r.slug AS rubrique_slug, r.couleur AS rubrique_couleur,
           u.prenom, u.nom AS auteur_nom, u.avatar, u.bio
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE a.slug = ? AND a.statut = 'publie'
");
$stmt->execute([$slug]);
$article = $stmt->fetch();

if (!$article) {
    http_response_code(404);
    $pageTitle = 'Article introuvable';
    require_once __DIR__ . '/includes/header.php';
    echo '<div class="container" style="padding: 200px 0; text-align: center;">
            <h1 style="font-size: 4rem; color: var(--text-muted);">404</h1>
            <p>Cet article n\'existe pas ou a été supprimé.</p>
            <a href="' . SITE_URL . '/" class="btn btn-primary mt-2">Retour à l\'accueil</a>
          </div>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Incrémenter les vues
$pdo->prepare("UPDATE articles SET vues = vues + 1 WHERE id = ?")->execute([$article['id']]);
logVisit('article-' . $article['id']);

// Commentaires
$stmtComments = $pdo->prepare("
    SELECT c.*, u.prenom, u.nom AS auteur_nom, u.avatar
    FROM commentaires c
    JOIN utilisateurs u ON c.auteur_id = u.id
    WHERE c.article_id = ? AND c.statut = 'approuve' AND c.parent_id IS NULL
    ORDER BY c.date_creation DESC
");
$stmtComments->execute([$article['id']]);
$commentaires = $stmtComments->fetchAll();

// Articles similaires
$stmtRelated = $pdo->prepare("
    SELECT a.id, a.titre, a.slug, a.image_principale, a.date_publication, a.vues,
           r.nom AS rubrique_nom, r.couleur AS rubrique_couleur
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    WHERE a.rubrique_id = ? AND a.id != ? AND a.statut = 'publie'
    ORDER BY a.date_publication DESC LIMIT 3
");
$stmtRelated->execute([$article['rubrique_id'], $article['id']]);
$relatedArticles = $stmtRelated->fetchAll();

// Traitement commentaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_submit'])) {
    if (!isLoggedIn()) {
        setFlash('error', 'Vous devez être connecté pour commenter.');
        redirect(SITE_URL . '/connexion.php');
    }
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token de sécurité invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }
    $contenu = trim($_POST['contenu'] ?? '');
    if (empty($contenu)) {
        setFlash('error', 'Le commentaire ne peut pas être vide.');
    } else {
        $stmtInsert = $pdo->prepare("INSERT INTO commentaires (contenu, article_id, auteur_id, statut) VALUES (?, ?, ?, 'approuve')");
        $stmtInsert->execute([sanitize($contenu), $article['id'], $_SESSION['user_id']]);
        setFlash('success', 'Commentaire ajouté avec succès !');
    }
    redirect($_SERVER['REQUEST_URI']);
}

$pageTitle = $article['titre'];
$currentRubrique = $article['rubrique_slug'];
require_once __DIR__ . '/includes/header.php';
?>

<!-- Article Header -->
<div class="article-header">
    <div class="container">
        <a href="<?= SITE_URL ?>/rubrique.php?slug=<?= $article['rubrique_slug'] ?>" 
           class="tag" style="background: <?= $article['rubrique_couleur'] ?>22; color: <?= $article['rubrique_couleur'] ?>;">
            <i class="fas fa-folder"></i> <?= sanitize($article['rubrique_nom']) ?>
        </a>
        <h1><?= sanitize($article['titre']) ?></h1>
        <div class="article-meta-bar">
            <span>
                <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($article['avatar']) ?>" 
                     alt="" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover;"
                     onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                <?= sanitize($article['prenom'] . ' ' . $article['auteur_nom']) ?>
            </span>
            <span><i class="far fa-calendar"></i> <?= formatDate($article['date_publication']) ?></span>
            <span><i class="far fa-eye"></i> <?= number_format($article['vues']) ?> vues</span>
            <?php if ($article['lieu_evenement']): ?>
            <span><i class="fas fa-map-marker-alt"></i> <?= sanitize($article['lieu_evenement']) ?></span>
            <?php endif; ?>
            <?php if ($article['date_evenement']): ?>
            <span><i class="fas fa-calendar-check"></i> Événement : <?= formatDate($article['date_evenement']) ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Article Cover -->
<?php if ($article['image_principale']): ?>
<div class="container">
    <div class="article-cover">
        <img src="<?= UPLOAD_URL ?>articles/<?= sanitize($article['image_principale']) ?>" alt="<?= sanitize($article['titre']) ?>">
    </div>
</div>
<?php endif; ?>

<!-- Article Content -->
<div class="container">
    <div class="article-content">
        <?= $article['contenu'] ?>
    </div>

    <!-- Share -->
    <div style="max-width: 780px; margin: var(--spacing-2xl) auto; padding: var(--spacing-lg); background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: var(--spacing-md);">
        <span style="font-weight: 600;">Partager cet article</span>
        <div style="display: flex; gap: var(--spacing-sm);">
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(SITE_URL . '/article.php?slug=' . $article['slug']) ?>" 
               target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com/intent/tweet?url=<?= urlencode(SITE_URL . '/article.php?slug=' . $article['slug']) ?>&text=<?= urlencode($article['titre']) ?>" 
               target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-twitter"></i></a>
            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?= urlencode(SITE_URL . '/article.php?slug=' . $article['slug']) ?>" 
               target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-linkedin-in"></i></a>
            <button class="btn btn-secondary btn-sm" onclick="navigator.clipboard.writeText(window.location.href); this.innerHTML='<i class=\'fas fa-check\'></i> Copié!';">
                <i class="fas fa-link"></i>
            </button>
        </div>
    </div>

    <!-- Commentaires -->
    <div style="max-width: 780px; margin: 0 auto var(--spacing-3xl);">
        <h3 style="font-family: var(--font-serif); font-size: 1.4rem; margin-bottom: var(--spacing-xl);">
            <i class="fas fa-comments text-accent"></i> Commentaires (<?= count($commentaires) ?>)
        </h3>

        <?php if (isLoggedIn()): ?>
        <form method="POST" style="margin-bottom: var(--spacing-2xl);">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <div class="form-group">
                <textarea name="contenu" class="form-control" placeholder="Écrivez votre commentaire..." rows="4" required></textarea>
            </div>
            <button type="submit" name="comment_submit" class="btn btn-primary">
                <i class="fas fa-paper-plane"></i> Publier
            </button>
        </form>
        <?php else: ?>
        <div class="card" style="padding: var(--spacing-lg); text-align: center; margin-bottom: var(--spacing-xl);">
            <p class="text-muted">
                <a href="<?= SITE_URL ?>/connexion.php">Connectez-vous</a> pour laisser un commentaire.
            </p>
        </div>
        <?php endif; ?>

        <?php foreach ($commentaires as $comment): ?>
        <div class="reply-item">
            <div class="reply-avatar">
                <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($comment['avatar']) ?>" alt=""
                     onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
            </div>
            <div class="reply-content">
                <div class="reply-header">
                    <span class="reply-author"><?= sanitize($comment['prenom'] . ' ' . $comment['auteur_nom']) ?></span>
                    <span class="reply-date"><?= formatDate($comment['date_creation'], 'relative') ?></span>
                </div>
                <div class="reply-body">
                    <p><?= nl2br(sanitize($comment['contenu'])) ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Articles similaires -->
    <?php if (!empty($relatedArticles)): ?>
    <div style="margin-bottom: var(--spacing-3xl);">
        <h3 class="section-title" style="margin-bottom: var(--spacing-xl);">
            Articles <span class="accent">similaires</span>
        </h3>
        <div class="grid grid-3">
            <?php foreach ($relatedArticles as $rel): ?>
            <article class="card">
                <div class="card-image">
                    <img src="<?= $rel['image_principale'] ? UPLOAD_URL . 'articles/' . sanitize($rel['image_principale']) : SITE_URL . '/assets/img/placeholder.jpg' ?>" 
                         alt="<?= sanitize($rel['titre']) ?>" loading="lazy">
                </div>
                <div class="card-body">
                    <span class="tag" style="background: <?= $rel['rubrique_couleur'] ?>22; color: <?= $rel['rubrique_couleur'] ?>; margin-bottom: var(--spacing-sm); display: inline-block;">
                        <?= sanitize($rel['rubrique_nom']) ?>
                    </span>
                    <h3 class="card-title">
                        <a href="<?= SITE_URL ?>/article.php?slug=<?= $rel['slug'] ?>"><?= sanitize($rel['titre']) ?></a>
                    </h3>
                    <div class="card-meta">
                        <span><i class="far fa-calendar"></i> <?= formatDate($rel['date_publication'], 'short') ?></span>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
