<?php
require_once __DIR__ . '/config.php';

// Récupérer les rubriques pour la navigation
$stmtRubriques = $pdo->query("SELECT * FROM rubriques WHERE statut = 'actif' ORDER BY ordre ASC");
$rubriquesNav = $stmtRubriques->fetchAll();

$csrf_token = generateCSRFToken();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= SITE_DESCRIPTION ?>">
    <title><?= isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME ?></title>
    
    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
    
    <?php if (isset($extraCSS)): ?>
    <?= $extraCSS ?>
    <?php endif; ?>
</head>
<body>

<!-- ===== HEADER ===== -->
<header class="header" id="mainHeader">
    <div class="container">
        <div class="header-inner">
            <a href="<?= SITE_URL ?>/" class="logo">
                <span class="logo-icon">AE</span>
                ACTU Events
            </a>

            <button class="menu-toggle" id="menuToggle" aria-label="Menu">
                <i class="fas fa-bars"></i>
            </button>

            <nav class="nav-main" id="navMain">
                <a href="<?= SITE_URL ?>/" class="<?= ($currentPage ?? '') === 'home' ? 'active' : '' ?>">
                    <i class="fas fa-home"></i> Accueil
                </a>
                <?php foreach (array_slice($rubriquesNav, 0, 5) as $rub): ?>
                <a href="<?= SITE_URL ?>/rubrique.php?slug=<?= $rub['slug'] ?>" class="<?= ($currentRubrique ?? '') === $rub['slug'] ? 'active' : '' ?>">
                    <i class="fas <?= $rub['icone'] ?>"></i> <?= sanitize($rub['nom']) ?>
                </a>
                <?php endforeach; ?>
                <a href="<?= SITE_URL ?>/forum.php" class="<?= ($currentPage ?? '') === 'forum' ? 'active' : '' ?>">
                    <i class="fas fa-comments"></i> Forum
                </a>
            </nav>

            <div class="nav-actions">
                <?php if (isLoggedIn()): ?>
                    <?php if (isAdmin() || isEditor()): ?>
                    <a href="<?= SITE_URL ?>/admin/" class="btn btn-ghost btn-sm">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <?php endif; ?>
                    <a href="<?= SITE_URL ?>/profil.php" class="btn btn-ghost btn-sm">
                        <i class="fas fa-user"></i> <?= sanitize($_SESSION['user_prenom'] ?? 'Profil') ?>
                    </a>
                    <a href="<?= SITE_URL ?>/deconnexion.php" class="btn btn-ghost btn-sm">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                <?php else: ?>
                    <a href="<?= SITE_URL ?>/connexion.php" class="btn btn-ghost btn-sm">Connexion</a>
                    <a href="<?= SITE_URL ?>/inscription.php" class="btn btn-primary btn-sm">S'inscrire</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<?php if ($flash): ?>
<div class="container" style="padding-top: 80px;">
    <div class="alert alert-<?= $flash['type'] ?>">
        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'error' ? 'exclamation-circle' : 'info-circle') ?>"></i>
        <?= $flash['message'] ?>
    </div>
</div>
<?php endif; ?>
