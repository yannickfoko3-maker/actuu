<!-- ===== FOOTER ===== -->
<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="<?= SITE_URL ?>/" class="logo">
                    <span class="logo-icon">AE</span>
                    ACTU Events
                </a>
                <p>Votre magazine d'actualités et d'événements. Restez informé des dernières manifestations, forums et conférences.</p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <div>
                <h4 class="footer-title">Rubriques</h4>
                <ul class="footer-links">
                    <?php
                    $footerRubs = $pdo->query("SELECT nom, slug FROM rubriques WHERE statut = 'actif' ORDER BY ordre ASC LIMIT 6")->fetchAll();
                    foreach ($footerRubs as $fr):
                    ?>
                    <li><a href="<?= SITE_URL ?>/rubrique.php?slug=<?= $fr['slug'] ?>"><?= sanitize($fr['nom']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div>
                <h4 class="footer-title">Liens utiles</h4>
                <ul class="footer-links">
                    <li><a href="<?= SITE_URL ?>/forum.php">Forum</a></li>
                    <li><a href="<?= SITE_URL ?>/inscription.php">S'inscrire</a></li>
                    <li><a href="#">À propos</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Mentions légales</a></li>
                </ul>
            </div>

            <div>
                <h4 class="footer-title">Newsletter</h4>
                <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: var(--spacing-md);">
                    Recevez les dernières actualités directement dans votre boîte mail.
                </p>
                <form action="<?= SITE_URL ?>/newsletter.php" method="POST" style="display: flex; gap: 8px;">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <input type="email" name="email" placeholder="Votre email" class="form-control" required style="flex: 1;">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>

        <!-- Partenaires -->
        <?php
        $pubs = $pdo->query("SELECT * FROM publicites WHERE statut = 'actif' AND position = 'footer' AND date_debut <= CURDATE() AND date_fin >= CURDATE() ORDER BY priorite DESC LIMIT 6")->fetchAll();
        if (!empty($pubs)):
        ?>
        <div style="margin-bottom: var(--spacing-2xl);">
            <h4 class="footer-title text-center" style="margin-bottom: var(--spacing-lg);">Nos Partenaires</h4>
            <div class="partner-slider">
                <?php foreach ($pubs as $pub): ?>
                <a href="<?= sanitize($pub['lien_url']) ?>" target="_blank" class="partner-slide" 
                   onclick="trackAdClick(<?= $pub['id'] ?>)">
                    <img src="<?= UPLOAD_URL ?>publicites/<?= sanitize($pub['image']) ?>" alt="<?= sanitize($pub['partenaire']) ?>">
                    <small class="text-muted"><?= sanitize($pub['partenaire']) ?></small>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="footer-bottom">
            <span>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. Tous droits réservés.</span>
            <span>Conçu avec <i class="fas fa-heart text-danger"></i> pour les événements</span>
        </div>
    </div>
</footer>

<!-- ===== SCRIPTS ===== -->
<script>
// Header scroll effect
const header = document.getElementById('mainHeader');
window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 50);
});

// Mobile menu toggle
const menuToggle = document.getElementById('menuToggle');
const navMain = document.getElementById('navMain');
if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        navMain.classList.toggle('open');
        const icon = menuToggle.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });
}

// Track ad clicks
function trackAdClick(adId) {
    fetch('<?= SITE_URL ?>/api/track_ad.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ad_id: adId, action: 'click' })
    }).catch(() => {});
}

// Fade-in animation on scroll
const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.card, .forum-card, .stat-card').forEach(el => {
    observer.observe(el);
});
</script>

<?php if (isset($extraJS)): ?>
<?= $extraJS ?>
<?php endif; ?>

</body>
</html>
