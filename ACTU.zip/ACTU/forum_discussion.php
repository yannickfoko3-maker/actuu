<?php
/**
 * ACTU EVENTS MAGAZINE - Discussion forum
 * Page d'un sujet avec réponses, upload d'images/vidéos
 */
$currentPage = 'forum';
require_once __DIR__ . '/config.php';

$sujetId = intval($_GET['id'] ?? 0);
if (!$sujetId) { redirect(SITE_URL . '/forum.php'); }

// Récupérer le sujet
$stmt = $pdo->prepare("
    SELECT sf.*, f.titre AS forum_titre, f.slug AS forum_slug,
           u.prenom, u.nom AS auteur_nom, u.avatar, u.role, u.date_inscription
    FROM sujets_forum sf
    JOIN forums f ON sf.forum_id = f.id
    JOIN utilisateurs u ON sf.auteur_id = u.id
    WHERE sf.id = ?
");
$stmt->execute([$sujetId]);
$sujet = $stmt->fetch();

if (!$sujet) {
    setFlash('error', 'Sujet introuvable.');
    redirect(SITE_URL . '/forum.php');
}

// Incrémenter les vues
$pdo->prepare("UPDATE sujets_forum SET vues = vues + 1 WHERE id = ?")->execute([$sujetId]);

// Récupérer les réponses avec médias
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * FORUM_REPLIES_PER_PAGE;

$stmtReplies = $pdo->prepare("
    SELECT r.*, u.prenom, u.nom AS auteur_nom, u.avatar, u.role, u.date_inscription
    FROM reponses_forum r
    JOIN utilisateurs u ON r.auteur_id = u.id
    WHERE r.sujet_id = ? AND r.statut = 'actif'
    ORDER BY r.date_creation ASC
    LIMIT ? OFFSET ?
");
$stmtReplies->execute([$sujetId, FORUM_REPLIES_PER_PAGE, $offset]);
$reponses = $stmtReplies->fetchAll();

$totalReplies = $pdo->prepare("SELECT COUNT(*) FROM reponses_forum WHERE sujet_id = ? AND statut = 'actif'");
$totalReplies->execute([$sujetId]);
$totalRepPages = ceil($totalReplies->fetchColumn() / FORUM_REPLIES_PER_PAGE);

// Récupérer les médias pour chaque réponse
foreach ($reponses as &$rep) {
    $stmtMedia = $pdo->prepare("SELECT * FROM medias_forum WHERE reponse_id = ?");
    $stmtMedia->execute([$rep['id']]);
    $rep['medias'] = $stmtMedia->fetchAll();
}
unset($rep);

// Médias du sujet original
$stmtSujetMedia = $pdo->prepare("SELECT * FROM medias_forum WHERE sujet_id = ? AND reponse_id IS NULL");
$stmtSujetMedia->execute([$sujetId]);
$sujetMedias = $stmtSujetMedia->fetchAll();

// Traitement nouvelle réponse
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_submit'])) {
    if (!isLoggedIn()) {
        setFlash('error', 'Connectez-vous pour répondre.');
        redirect(SITE_URL . '/connexion.php');
    }
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }

    $contenu = trim($_POST['contenu'] ?? '');
    if (empty($contenu)) {
        setFlash('error', 'Le message ne peut pas être vide.');
        redirect($_SERVER['REQUEST_URI']);
    }

    // Insérer la réponse
    $stmtInsert = $pdo->prepare("INSERT INTO reponses_forum (contenu, sujet_id, auteur_id) VALUES (?, ?, ?)");
    $stmtInsert->execute([sanitize($contenu), $sujetId, $_SESSION['user_id']]);
    $reponseId = $pdo->lastInsertId();

    // Upload des fichiers
    if (!empty($_FILES['medias']['name'][0])) {
        $files = $_FILES['medias'];
        $nbFiles = count($files['name']);
        for ($i = 0; $i < min($nbFiles, 5); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                $result = uploadFile($file, 'forum');
                if ($result['success']) {
                    $pdo->prepare("INSERT INTO medias_forum (nom_fichier, chemin, type_mime, taille, reponse_id, sujet_id, uploadeur_id) VALUES (?, ?, ?, ?, ?, ?, ?)")
                        ->execute([$files['name'][$i], $result['path'], $result['mime'], $result['size'], $reponseId, $sujetId, $_SESSION['user_id']]);
                }
            }
        }
    }

    // Mettre à jour les compteurs
    $pdo->prepare("UPDATE sujets_forum SET nb_reponses = nb_reponses + 1, date_derniere_reponse = NOW() WHERE id = ?")->execute([$sujetId]);
    $pdo->prepare("UPDATE forums SET nb_messages = nb_messages + 1, date_dernier_message = NOW() WHERE id = ?")->execute([$sujet['forum_id']]);

    setFlash('success', 'Réponse publiée avec succès !');
    redirect(SITE_URL . '/forum_discussion.php?id=' . $sujetId . '#bottom');
}

$pageTitle = $sujet['titre'] . ' - Forum';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Breadcrumb -->
<section style="padding-top: 90px;">
    <div class="container">
        <div style="display: flex; align-items: center; gap: var(--spacing-sm); font-size: 0.85rem; color: var(--text-muted); flex-wrap: wrap;">
            <a href="<?= SITE_URL ?>/forum.php">Forum</a>
            <i class="fas fa-chevron-right" style="font-size: 0.6rem;"></i>
            <a href="<?= SITE_URL ?>/forum_sujet.php?slug=<?= $sujet['forum_slug'] ?>"><?= sanitize($sujet['forum_titre']) ?></a>
            <i class="fas fa-chevron-right" style="font-size: 0.6rem;"></i>
            <span class="text-primary"><?= sanitize(truncateText($sujet['titre'], 50)) ?></span>
        </div>
    </div>
</section>

<!-- Sujet -->
<section class="section">
    <div class="container">
        <div style="margin-bottom: var(--spacing-xl);">
            <h1 style="font-family: var(--font-serif); font-size: 1.8rem; font-weight: 700; margin-bottom: var(--spacing-sm);">
                <?php if ($sujet['epingle']): ?><i class="fas fa-thumbtack text-accent"></i> <?php endif; ?>
                <?= sanitize($sujet['titre']) ?>
            </h1>
            <div style="display: flex; gap: var(--spacing-lg); font-size: 0.85rem; color: var(--text-muted); flex-wrap: wrap;">
                <span><i class="far fa-eye"></i> <?= number_format($sujet['vues']) ?> vues</span>
                <span><i class="fas fa-reply"></i> <?= $sujet['nb_reponses'] ?> réponses</span>
                <span><i class="far fa-clock"></i> Créé <?= formatDate($sujet['date_creation'], 'relative') ?></span>
                <span class="tag tag-<?= $sujet['statut'] === 'ouvert' ? 'success' : 'warning' ?>">
                    <?= ucfirst($sujet['statut']) ?>
                </span>
            </div>
        </div>

        <!-- Message original -->
        <div class="card" style="margin-bottom: var(--spacing-lg);">
            <div class="reply-item" style="border-bottom: none;">
                <div class="reply-avatar">
                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($sujet['avatar']) ?>" alt=""
                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                </div>
                <div class="reply-content">
                    <div class="reply-header">
                        <div>
                            <span class="reply-author"><?= sanitize($sujet['prenom'] . ' ' . $sujet['auteur_nom']) ?></span>
                            <span class="tag tag-primary" style="margin-left: 8px; padding: 1px 6px; font-size: 0.65rem;">
                                <?= ucfirst($sujet['role']) ?>
                            </span>
                        </div>
                        <span class="reply-date"><?= formatDate($sujet['date_creation']) ?></span>
                    </div>
                    <div class="reply-body">
                        <?= nl2br(sanitize($sujet['contenu'])) ?>
                        
                        <?php foreach ($sujetMedias as $media): ?>
                        <div style="margin-top: var(--spacing-md);">
                            <?php if (strpos($media['type_mime'], 'image') !== false): ?>
                            <img src="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" alt="<?= sanitize($media['nom_fichier']) ?>" 
                                 style="max-width: 100%; border-radius: var(--radius-md);">
                            <?php elseif (strpos($media['type_mime'], 'video') !== false): ?>
                            <video controls style="max-width: 100%; border-radius: var(--radius-md);">
                                <source src="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" type="<?= $media['type_mime'] ?>">
                            </video>
                            <?php else: ?>
                            <a href="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" class="btn btn-secondary btn-sm" download>
                                <i class="fas fa-download"></i> <?= sanitize($media['nom_fichier']) ?>
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Réponses -->
        <?php if (!empty($reponses)): ?>
        <h3 style="font-weight: 700; margin-bottom: var(--spacing-lg);">
            <i class="fas fa-reply-all text-accent"></i> Réponses (<?= $sujet['nb_reponses'] ?>)
        </h3>
        <div class="card" style="margin-bottom: var(--spacing-xl);">
            <?php foreach ($reponses as $rep): ?>
            <div class="reply-item">
                <div class="reply-avatar">
                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($rep['avatar']) ?>" alt=""
                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                </div>
                <div class="reply-content">
                    <div class="reply-header">
                        <div>
                            <span class="reply-author"><?= sanitize($rep['prenom'] . ' ' . $rep['auteur_nom']) ?></span>
                            <span class="tag tag-primary" style="margin-left: 4px; padding: 1px 6px; font-size: 0.65rem;">
                                <?= ucfirst($rep['role']) ?>
                            </span>
                        </div>
                        <span class="reply-date"><?= formatDate($rep['date_creation'], 'relative') ?></span>
                    </div>
                    <div class="reply-body">
                        <p><?= nl2br(sanitize($rep['contenu'])) ?></p>
                        
                        <?php if (!empty($rep['medias'])): ?>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: var(--spacing-sm); margin-top: var(--spacing-md);">
                            <?php foreach ($rep['medias'] as $media): ?>
                                <?php if (strpos($media['type_mime'], 'image') !== false): ?>
                                <img src="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" alt="" 
                                     style="border-radius: var(--radius-sm); cursor: pointer; max-height: 250px; object-fit: cover; width: 100%;"
                                     onclick="window.open(this.src)">
                                <?php elseif (strpos($media['type_mime'], 'video') !== false): ?>
                                <video controls style="max-width: 100%; border-radius: var(--radius-sm);">
                                    <source src="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" type="<?= $media['type_mime'] ?>">
                                </video>
                                <?php else: ?>
                                <a href="<?= UPLOAD_URL . sanitize($media['chemin']) ?>" class="btn btn-secondary btn-sm" download>
                                    <i class="fas fa-download"></i> <?= sanitize($media['nom_fichier']) ?>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="reply-actions">
                        <button onclick="likeReply(<?= $rep['id'] ?>, this)">
                            <i class="far fa-heart"></i> <span><?= $rep['likes'] ?></span>
                        </button>
                        <button onclick="document.getElementById('contenu').focus();">
                            <i class="fas fa-reply"></i> Répondre
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination réponses -->
        <?php if ($totalRepPages > 1): ?>
        <nav class="pagination">
            <?php for ($i = 1; $i <= $totalRepPages; $i++): ?>
                <?php if ($i == $page): ?>
                <span class="active"><?= $i ?></span>
                <?php else: ?>
                <a href="?id=<?= $sujetId ?>&page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </nav>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Formulaire de réponse -->
        <div id="bottom" style="margin-top: var(--spacing-xl);">
            <?php if (isLoggedIn()): ?>
            <h3 style="font-weight: 700; margin-bottom: var(--spacing-lg);">
                <i class="fas fa-pen text-accent"></i> Votre réponse
            </h3>
            <div class="card" style="padding: var(--spacing-lg);">
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                    <!-- Éditeur de texte enrichi -->
                    <div class="form-group">
                        <div class="editor-toolbar">
                            <button type="button" onclick="formatText('bold')" title="Gras"><i class="fas fa-bold"></i></button>
                            <button type="button" onclick="formatText('italic')" title="Italique"><i class="fas fa-italic"></i></button>
                            <button type="button" onclick="formatText('underline')" title="Souligné"><i class="fas fa-underline"></i></button>
                            <span class="separator"></span>
                            <button type="button" onclick="formatText('insertUnorderedList')" title="Liste"><i class="fas fa-list-ul"></i></button>
                            <button type="button" onclick="formatText('insertOrderedList')" title="Liste numérotée"><i class="fas fa-list-ol"></i></button>
                            <span class="separator"></span>
                            <button type="button" onclick="insertLink()" title="Lien"><i class="fas fa-link"></i></button>
                        </div>
                        <textarea name="contenu" id="contenu" class="form-control" 
                                  style="border-radius: 0 0 var(--radius-sm) var(--radius-sm); min-height: 150px;"
                                  placeholder="Partagez votre avis, posez une question..." required></textarea>
                    </div>

                    <!-- Zone d'upload -->
                    <div class="form-group">
                        <label class="form-label">Ajouter des médias (images, vidéos - max 5 fichiers)</label>
                        <div class="upload-zone" id="uploadZone" onclick="document.getElementById('mediaInput').click();">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Glissez vos fichiers ici ou <strong>cliquez pour parcourir</strong></p>
                            <p class="upload-formats">Images (JPG, PNG, GIF, WebP) • Vidéos (MP4, WebM) • Max 10 Mo par fichier</p>
                        </div>
                        <input type="file" name="medias[]" id="mediaInput" multiple accept="image/*,video/*" style="display: none;">
                        <div id="previewZone" style="display: flex; gap: var(--spacing-sm); flex-wrap: wrap; margin-top: var(--spacing-sm);"></div>
                    </div>

                    <button type="submit" name="reply_submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane"></i> Publier ma réponse
                    </button>
                </form>
            </div>
            <?php else: ?>
            <div class="card" style="padding: var(--spacing-2xl); text-align: center;">
                <i class="fas fa-lock" style="font-size: 2rem; color: var(--text-muted); margin-bottom: var(--spacing-md);"></i>
                <h3>Connectez-vous pour répondre</h3>
                <p class="text-muted mb-2">Vous devez être membre pour participer à la discussion.</p>
                <a href="<?= SITE_URL ?>/connexion.php" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt"></i> Se connecter
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
$extraJS = <<<'JS'
<script>
// Drag & Drop upload
const uploadZone = document.getElementById('uploadZone');
const mediaInput = document.getElementById('mediaInput');
const previewZone = document.getElementById('previewZone');

if (uploadZone) {
    ['dragover', 'dragenter'].forEach(e => {
        uploadZone.addEventListener(e, (ev) => {
            ev.preventDefault();
            uploadZone.classList.add('dragover');
        });
    });
    ['dragleave', 'drop'].forEach(e => {
        uploadZone.addEventListener(e, (ev) => {
            ev.preventDefault();
            uploadZone.classList.remove('dragover');
        });
    });
    uploadZone.addEventListener('drop', (e) => {
        mediaInput.files = e.dataTransfer.files;
        showPreviews(e.dataTransfer.files);
    });
    mediaInput.addEventListener('change', () => {
        showPreviews(mediaInput.files);
    });
}

function showPreviews(files) {
    previewZone.innerHTML = '';
    Array.from(files).forEach(file => {
        const div = document.createElement('div');
        div.style.cssText = 'position:relative;width:100px;height:100px;border-radius:8px;overflow:hidden;border:1px solid var(--border-color);';
        
        if (file.type.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
            div.appendChild(img);
        } else if (file.type.startsWith('video/')) {
            div.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;background:var(--bg-secondary);"><i class="fas fa-video" style="font-size:1.5rem;color:var(--accent-primary);"></i></div>';
        }
        
        const label = document.createElement('div');
        label.style.cssText = 'position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,0.7);padding:2px 4px;font-size:0.65rem;color:white;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
        label.textContent = file.name;
        div.appendChild(label);
        
        previewZone.appendChild(div);
    });
}

// Simple text formatting
function formatText(command) {
    const textarea = document.getElementById('contenu');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.substring(start, end);
    
    let wrapper = '';
    switch(command) {
        case 'bold': wrapper = '**'; break;
        case 'italic': wrapper = '*'; break;
        case 'underline': wrapper = '__'; break;
    }
    
    if (wrapper) {
        textarea.value = textarea.value.substring(0, start) + wrapper + selected + wrapper + textarea.value.substring(end);
        textarea.focus();
    }
}

function insertLink() {
    const url = prompt('Entrez l\'URL:');
    if (url) {
        const textarea = document.getElementById('contenu');
        const start = textarea.selectionStart;
        textarea.value = textarea.value.substring(0, start) + url + textarea.value.substring(start);
        textarea.focus();
    }
}

// Like
function likeReply(replyId, btn) {
    fetch('<?= SITE_URL ?>/api/like.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply_id: replyId })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const span = btn.querySelector('span');
            span.textContent = data.likes;
            btn.querySelector('i').classList.toggle('fas');
            btn.querySelector('i').classList.toggle('far');
        }
    })
    .catch(() => {});
}
</script>
JS;

require_once __DIR__ . '/includes/footer.php';
?>
