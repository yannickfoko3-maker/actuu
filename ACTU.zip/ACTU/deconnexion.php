<?php
/**
 * ACTU EVENTS MAGAZINE - Déconnexion
 */
require_once __DIR__ . '/config.php';
session_destroy();
header("Location: " . SITE_URL . "/");
exit;
