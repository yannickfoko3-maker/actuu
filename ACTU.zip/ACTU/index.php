<?php
/**
 * ACTU EVENTS MAGAZINE - Page d'accueil
 * Affiche les articles récents, articles mis en avant, et publicités
 */
$currentPage = 'home';
$pageTitle = 'Accueil';

require_once __DIR__ . '/config.php';
logVisit('accueil');

// Article mis en avant
$stmtFeatured = $pdo->query("
    SELECT a.*, r.nom AS rubrique_nom, r.slug AS rubrique_slug, r.couleur AS rubrique_couleur,
           u.prenom, u.nom AS auteur_nom, u.avatar
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE a.statut = 'publie' AND a.mise_en_avant = 1
    ORDER BY a.date_publication DESC LIMIT 1
");
$featured = $stmtFeatured->fetch();

// Articles récents
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * ARTICLES_PER_PAGE;

$stmtTotal = $pdo->query("SELECT COUNT(*) FROM articles WHERE statut = 'publie'");
$totalArticles = $stmtTotal->fetchColumn();
$totalPages = ceil($totalArticles / ARTICLES_PER_PAGE);

$stmtArticles = $pdo->prepare("
    SELECT a.*, r.nom AS rubrique_nom, r.slug AS rubrique_slug, r.couleur AS rubrique_couleur,
           u.prenom, u.nom AS auteur_nom, u.avatar
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE a.statut = 'publie'
    ORDER BY a.date_publication DESC
    LIMIT ? OFFSET ?
");
$stmtArticles->execute([ARTICLES_PER_PAGE, $offset]);
$articles = $stmtArticles->fetchAll();

// Rubriques avec compteur
$stmtCats = $pdo->query("
    SELECT r.*, COUNT(a.id) AS nb_articles
    FROM rubriques r
    LEFT JOIN articles a ON a.rubrique_id = r.id AND a.statut = 'publie'
    WHERE r.statut = 'actif'
    GROUP BY r.id
    ORDER BY r.ordre ASC
");
$categories = $stmtCats->fetchAll();

// Publicités sidebar
$stmtAds = $pdo->query("
    SELECT * FROM publicites
    WHERE statut = 'actif' AND position = 'sidebar' AND date_debut <= CURDATE() AND date_fin >= CURDATE()
    ORDER BY priorite DESC LIMIT 3
");
$sidebarAds = $stmtAds->fetchAll();

// Articles populaires
$stmtPopular = $pdo->query("
    SELECT a.id, a.titre, a.slug, a.image_principale, a.vues, a.date_publication,
           r.nom AS rubrique_nom, r.couleur AS rubrique_couleur
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    WHERE a.statut = 'publie'
    ORDER BY a.vues DESC LIMIT 5
");
$popularArticles = $stmtPopular->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<!-- ===== HERO ===== -->
<section class="hero">
    <div class="container">
        <div class="hero-subtitle">
            <i class="fas fa-bolt"></i> Le magazine de vos événements
        </div>
        <h1 class="hero-title">
            Découvrez les <span class="gradient-text">événements</span><br>
            qui font l'actualité
        </h1>
        <p class="hero-description">
            Forums, conférences, ateliers et bien plus encore. Restez informé et participez aux discussions autour des thématiques qui comptent.
        </p>
    </div>
</section>

<!-- ===== ARTICLE MIS EN AVANT ===== -->
<?php if ($featured): ?>
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="card card-featured">
            <div class="card-image">
                <img src="<?= $featured['image_principale'] ? UPLOAD_URL . 'articles/' . sanitize($featured['image_principale']) : SITE_URL . '/assets/img/placeholder.jpg' ?>" 
                     alt="<?= sanitize($featured['titre']) ?>">
            </div>
            <div class="card-body">
                <span class="tag" style="background: <?= $featured['rubrique_couleur'] ?>22; color: <?= $featured['rubrique_couleur'] ?>;">
                    <?= sanitize($featured['rubrique_nom']) ?>
                </span>
                <h2 class="card-title" style="margin-top: var(--spacing-md);">
                    <a href="<?= SITE_URL ?>/article.php?slug=<?= $featured['slug'] ?>">
                        <?= sanitize($featured['titre']) ?>
                    </a>
                </h2>
                <p class="card-excerpt"><?= truncateText($featured['extrait'] ?? $featured['contenu'], 200) ?></p>
                <div class="card-footer" style="border-top-color: rgba(255,255,255,0.1);">
                    <div class="card-author">
                        <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($featured['avatar']) ?>" alt="" class="card-author-avatar"
                             onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                        <span class="card-author-name"><?= sanitize($featured['prenom'] . ' ' . $featured['auteur_nom']) ?></span>
                    </div>
                    <span class="text-muted" style="font-size: 0.85rem;">
                        <i class="far fa-clock"></i> <?= formatDate($featured['date_publication'], 'short') ?>
                        &nbsp;&middot;&nbsp;
                        <i class="far fa-eye"></i> <?= number_format($featured['vues']) ?> vues
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ===== RUBRIQUES TABS ===== -->
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Explorer par <span class="accent">thématique</span></h2>
        </div>
        <div style="display: flex; gap: var(--spacing-sm); flex-wrap: wrap; margin-bottom: var(--spacing-xl);">
            <?php foreach ($categories as $cat): ?>
            <a href="<?= SITE_URL ?>/rubrique.php?slug=<?= $cat['slug'] ?>" class="btn btn-secondary btn-sm" 
               style="border-color: <?= $cat['couleur'] ?>33;">
                <i class="fas <?= $cat['icone'] ?>" style="color: <?= $cat['couleur'] ?>;"></i>
                <?= sanitize($cat['nom']) ?>
                <span class="tag tag-primary" style="margin-left: 4px; padding: 2px 6px; font-size: 0.7rem;">
                    <?= $cat['nb_articles'] ?>
                </span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===== ARTICLES RÉCENTS + SIDEBAR ===== -->
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Dernières <span class="accent">actualités</span></h2>
            <div>
                <a href="<?= SITE_URL ?>/archives.php" class="btn btn-ghost btn-sm">
                    Voir tout <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>

        <div class="grid-sidebar">
            <!-- Articles grid -->
            <div>
                <?php if (empty($articles)): ?>
                <div class="card" style="padding: var(--spacing-2xl); text-align: center;">
                    <i class="fas fa-newspaper" style="font-size: 3rem; color: var(--text-muted); margin-bottom: var(--spacing-md);"></i>
                    <h3>Aucun article pour le moment</h3>
                    <p class="text-muted">Les articles apparaîtront ici dès leur publication.</p>
                </div>
                <?php else: ?>
                <div class="grid grid-articles">
                    <?php foreach ($articles as $art): ?>
                    <article class="card fade-in-up">
                        <div class="card-image">
                            <img src="<?= $art['image_principale'] ? UPLOAD_URL . 'articles/' . sanitize($art['image_principale']) : SITE_URL . '/assets/img/placeholder.jpg' ?>" 
                                 alt="<?= sanitize($art['titre']) ?>"
                                 loading="lazy">
                            <span class="card-badge" style="background: <?= $art['rubrique_couleur'] ?>DD;">
                                <?= sanitize($art['rubrique_nom']) ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="card-meta">
                                <span><i class="far fa-calendar"></i> <?= formatDate($art['date_publication'], 'short') ?></span>
                                <span><i class="far fa-eye"></i> <?= number_format($art['vues']) ?></span>
                                <?php if ($art['lieu_evenement']): ?>
                                <span><i class="fas fa-map-marker-alt"></i> <?= sanitize($art['lieu_evenement']) ?></span>
                                <?php endif; ?>
                            </div>
                            <h3 class="card-title">
                                <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>">
                                    <?= sanitize($art['titre']) ?>
                                </a>
                            </h3>
                            <p class="card-excerpt">
                                <?= truncateText($art['extrait'] ?? $art['contenu']) ?>
                            </p>
                            <div class="card-footer">
                                <div class="card-author">
                                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($art['avatar']) ?>" alt="" class="card-author-avatar"
                                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                                    <span class="card-author-name"><?= sanitize($art['prenom']) ?></span>
                                </div>
                                <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>" class="btn btn-ghost btn-sm">
                                    Lire <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <nav class="pagination">
                    <?php if ($page > 1): ?>
                    <a href="?page=<?= $page - 1 ?>"><i class="fas fa-chevron-left"></i></a>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                        <?php if ($i == $page): ?>
                        <span class="active"><?= $i ?></span>
                        <?php else: ?>
                        <a href="?page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                    <a href="?page=<?= $page + 1 ?>"><i class="fas fa-chevron-right"></i></a>
                    <?php endif; ?>
                </nav>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <aside>
                <!-- Articles populaires -->
                <div class="sidebar-widget">
                    <h3 class="sidebar-widget-title"><i class="fas fa-fire"></i> Tendances</h3>
                    <?php foreach ($popularArticles as $idx => $pop): ?>
                    <div style="display: flex; gap: var(--spacing-md); margin-bottom: var(--spacing-md); align-items: flex-start;">
                        <span style="font-size: 1.8rem; font-weight: 900; color: var(--accent-primary); opacity: 0.3; line-height: 1; min-width: 30px;">
                            <?= str_pad($idx + 1, 2, '0', STR_PAD_LEFT) ?>
                        </span>
                        <div>
                            <a href="<?= SITE_URL ?>/article.php?slug=<?= $pop['slug'] ?>" 
                               style="font-weight: 600; font-size: 0.9rem; color: var(--text-primary); display: block; margin-bottom: 4px;">
                                <?= sanitize(truncateText($pop['titre'], 60)) ?>
                            </a>
                            <span class="text-muted" style="font-size: 0.78rem;">
                                <i class="far fa-eye"></i> <?= number_format($pop['vues']) ?> vues
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Publicités partenaires -->
                <?php foreach ($sidebarAds as $ad): ?>
                <div class="ad-banner" style="margin-bottom: var(--spacing-lg);">
                    <span class="ad-banner-label">Partenaire</span>
                    <a href="<?= sanitize($ad['lien_url']) ?>" target="_blank" onclick="trackAdClick(<?= $ad['id'] ?>)">
                        <img src="<?= UPLOAD_URL ?>publicites/<?= sanitize($ad['image']) ?>" 
                             alt="<?= sanitize($ad['partenaire']) ?>">
                    </a>
                </div>
                <?php endforeach; ?>

                <!-- Rejoindre le forum -->
                <div class="sidebar-widget" style="background: linear-gradient(135deg, rgba(108,99,255,0.1), rgba(168,85,247,0.1)); border-color: rgba(108,99,255,0.2);">
                    <h3 class="sidebar-widget-title"><i class="fas fa-comments"></i> Forum</h3>
                    <p style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: var(--spacing-md);">
                        Participez aux discussions, partagez vos idées et connectez-vous avec la communauté.
                    </p>
                    <a href="<?= SITE_URL ?>/forum.php" class="btn btn-primary w-100">
                        <i class="fas fa-arrow-right"></i> Accéder au forum
                    </a>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
