<?php
/**
 * Page 404
 */
$pageTitle = 'Page introuvable';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container" style="padding: 200px 0; text-align: center;">
    <h1 style="font-size: 6rem; font-weight: 900; background: var(--accent-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: var(--spacing-md);">404</h1>
    <h2 style="font-family: var(--font-serif); margin-bottom: var(--spacing-md);">Page introuvable</h2>
    <p class="text-muted" style="margin-bottom: var(--spacing-xl);">La page que vous recherchez n'existe pas ou a été déplacée.</p>
    <a href="<?= SITE_URL ?>/" class="btn btn-primary btn-lg"><i class="fas fa-home"></i> Retour à l'accueil</a>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
