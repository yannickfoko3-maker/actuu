<?php
/**
 * Page 403 - Accès interdit
 */
$pageTitle = 'Accès interdit';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container" style="padding: 200px 0; text-align: center;">
    <h1 style="font-size: 6rem; font-weight: 900; background: linear-gradient(135deg, #FF6B6B, #FFB84D); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: var(--spacing-md);">403</h1>
    <h2 style="font-family: var(--font-serif); margin-bottom: var(--spacing-md);">Accès interdit</h2>
    <p class="text-muted" style="margin-bottom: var(--spacing-xl);">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
    <a href="<?= SITE_URL ?>/" class="btn btn-primary btn-lg"><i class="fas fa-home"></i> Retour à l'accueil</a>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
