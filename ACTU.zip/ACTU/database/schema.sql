-- ============================================================
-- ACTU EVENTS MAGAZINE - Schéma de base de données MySQL
-- Compatible LWS / MySQL 5.7+
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `if0_43217089_actu_events` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `if0_43217089_actu_events`;

-- ============================================================
-- TABLE: utilisateurs
-- ============================================================
CREATE TABLE `utilisateurs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(100) NOT NULL,
  `prenom` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `mot_de_passe` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255) DEFAULT 'default-avatar.png',
  `role` ENUM('admin','editeur','moderateur','utilisateur') NOT NULL DEFAULT 'utilisateur',
  `bio` TEXT DEFAULT NULL,
  `statut` ENUM('actif','inactif','banni') NOT NULL DEFAULT 'actif',
  `date_inscription` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `derniere_connexion` DATETIME DEFAULT NULL,
  `token_reset` VARCHAR(255) DEFAULT NULL,
  `token_expiration` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_email` (`email`),
  INDEX `idx_role` (`role`),
  INDEX `idx_statut` (`statut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: rubriques (catégories/thématiques)
-- ============================================================
CREATE TABLE `rubriques` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(150) NOT NULL UNIQUE,
  `description` TEXT DEFAULT NULL,
  `couleur` VARCHAR(7) DEFAULT '#6C63FF',
  `icone` VARCHAR(50) DEFAULT 'fa-folder',
  `ordre` INT(11) NOT NULL DEFAULT 0,
  `statut` ENUM('actif','inactif') NOT NULL DEFAULT 'actif',
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_statut` (`statut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: articles
-- ============================================================
CREATE TABLE `articles` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `contenu` LONGTEXT NOT NULL,
  `extrait` TEXT DEFAULT NULL,
  `image_principale` VARCHAR(255) DEFAULT NULL,
  `rubrique_id` INT(11) NOT NULL,
  `auteur_id` INT(11) NOT NULL,
  `statut` ENUM('brouillon','publie','archive') NOT NULL DEFAULT 'brouillon',
  `mise_en_avant` TINYINT(1) NOT NULL DEFAULT 0,
  `vues` INT(11) NOT NULL DEFAULT 0,
  `date_evenement` DATE DEFAULT NULL,
  `lieu_evenement` VARCHAR(255) DEFAULT NULL,
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `date_publication` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_rubrique` (`rubrique_id`),
  INDEX `idx_auteur` (`auteur_id`),
  INDEX `idx_statut` (`statut`),
  INDEX `idx_date_publication` (`date_publication`),
  CONSTRAINT `fk_articles_rubrique` FOREIGN KEY (`rubrique_id`) REFERENCES `rubriques` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_articles_auteur` FOREIGN KEY (`auteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: tags
-- ============================================================
CREATE TABLE `tags` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: article_tags (liaison articles <-> tags)
-- ============================================================
CREATE TABLE `article_tags` (
  `article_id` INT(11) NOT NULL,
  `tag_id` INT(11) NOT NULL,
  PRIMARY KEY (`article_id`, `tag_id`),
  CONSTRAINT `fk_at_article` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_at_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: forums (thématiques de forum)
-- ============================================================
CREATE TABLE `forums` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `description` TEXT DEFAULT NULL,
  `image` VARCHAR(255) DEFAULT NULL,
  `rubrique_id` INT(11) DEFAULT NULL,
  `createur_id` INT(11) NOT NULL,
  `statut` ENUM('ouvert','ferme','archive') NOT NULL DEFAULT 'ouvert',
  `nb_sujets` INT(11) NOT NULL DEFAULT 0,
  `nb_messages` INT(11) NOT NULL DEFAULT 0,
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_dernier_message` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_slug` (`slug`),
  INDEX `idx_rubrique` (`rubrique_id`),
  INDEX `idx_statut` (`statut`),
  CONSTRAINT `fk_forums_rubrique` FOREIGN KEY (`rubrique_id`) REFERENCES `rubriques` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_forums_createur` FOREIGN KEY (`createur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: sujets_forum
-- ============================================================
CREATE TABLE `sujets_forum` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `contenu` LONGTEXT NOT NULL,
  `forum_id` INT(11) NOT NULL,
  `auteur_id` INT(11) NOT NULL,
  `statut` ENUM('ouvert','ferme','resolu') NOT NULL DEFAULT 'ouvert',
  `epingle` TINYINT(1) NOT NULL DEFAULT 0,
  `vues` INT(11) NOT NULL DEFAULT 0,
  `nb_reponses` INT(11) NOT NULL DEFAULT 0,
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_derniere_reponse` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_forum` (`forum_id`),
  INDEX `idx_auteur` (`auteur_id`),
  INDEX `idx_statut` (`statut`),
  CONSTRAINT `fk_sujets_forum` FOREIGN KEY (`forum_id`) REFERENCES `forums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sujets_auteur` FOREIGN KEY (`auteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: reponses_forum
-- ============================================================
CREATE TABLE `reponses_forum` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `contenu` LONGTEXT NOT NULL,
  `sujet_id` INT(11) NOT NULL,
  `auteur_id` INT(11) NOT NULL,
  `parent_id` INT(11) DEFAULT NULL,
  `statut` ENUM('actif','masque','signale') NOT NULL DEFAULT 'actif',
  `likes` INT(11) NOT NULL DEFAULT 0,
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_sujet` (`sujet_id`),
  INDEX `idx_auteur` (`auteur_id`),
  INDEX `idx_parent` (`parent_id`),
  CONSTRAINT `fk_reponses_sujet` FOREIGN KEY (`sujet_id`) REFERENCES `sujets_forum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_reponses_auteur` FOREIGN KEY (`auteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_reponses_parent` FOREIGN KEY (`parent_id`) REFERENCES `reponses_forum` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: medias_forum (fichiers joints aux messages)
-- ============================================================
CREATE TABLE `medias_forum` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nom_fichier` VARCHAR(255) NOT NULL,
  `chemin` VARCHAR(255) NOT NULL,
  `type_mime` VARCHAR(100) NOT NULL,
  `taille` INT(11) NOT NULL DEFAULT 0,
  `reponse_id` INT(11) DEFAULT NULL,
  `sujet_id` INT(11) DEFAULT NULL,
  `uploadeur_id` INT(11) NOT NULL,
  `date_upload` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_reponse` (`reponse_id`),
  INDEX `idx_sujet` (`sujet_id`),
  CONSTRAINT `fk_medias_reponse` FOREIGN KEY (`reponse_id`) REFERENCES `reponses_forum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_medias_sujet` FOREIGN KEY (`sujet_id`) REFERENCES `sujets_forum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_medias_uploadeur` FOREIGN KEY (`uploadeur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: commentaires (sur articles)
-- ============================================================
CREATE TABLE `commentaires` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `contenu` TEXT NOT NULL,
  `article_id` INT(11) NOT NULL,
  `auteur_id` INT(11) NOT NULL,
  `parent_id` INT(11) DEFAULT NULL,
  `statut` ENUM('approuve','en_attente','rejete') NOT NULL DEFAULT 'en_attente',
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_article` (`article_id`),
  INDEX `idx_auteur` (`auteur_id`),
  CONSTRAINT `fk_commentaires_article` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_commentaires_auteur` FOREIGN KEY (`auteur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_commentaires_parent` FOREIGN KEY (`parent_id`) REFERENCES `commentaires` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: publicites (partenaires)
-- ============================================================
CREATE TABLE `publicites` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(255) NOT NULL,
  `partenaire` VARCHAR(255) NOT NULL,
  `image` VARCHAR(255) NOT NULL,
  `lien_url` VARCHAR(500) DEFAULT NULL,
  `position` ENUM('sidebar','header','footer','inline','popup') NOT NULL DEFAULT 'sidebar',
  `priorite` INT(11) NOT NULL DEFAULT 0,
  `impressions` INT(11) NOT NULL DEFAULT 0,
  `clics` INT(11) NOT NULL DEFAULT 0,
  `date_debut` DATE NOT NULL,
  `date_fin` DATE NOT NULL,
  `statut` ENUM('actif','inactif','expire') NOT NULL DEFAULT 'actif',
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_position` (`position`),
  INDEX `idx_statut` (`statut`),
  INDEX `idx_dates` (`date_debut`, `date_fin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: statistiques_visites
-- ============================================================
CREATE TABLE `statistiques_visites` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `page` VARCHAR(255) NOT NULL,
  `ip_visiteur` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `utilisateur_id` INT(11) DEFAULT NULL,
  `date_visite` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_page` (`page`),
  INDEX `idx_date` (`date_visite`),
  INDEX `idx_utilisateur` (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: newsletters
-- ============================================================
CREATE TABLE `newsletters` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `statut` ENUM('abonne','desabonne') NOT NULL DEFAULT 'abonne',
  `date_inscription` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: likes_forum
-- ============================================================
CREATE TABLE `likes_forum` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `utilisateur_id` INT(11) NOT NULL,
  `reponse_id` INT(11) NOT NULL,
  `date_creation` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_like` (`utilisateur_id`, `reponse_id`),
  CONSTRAINT `fk_likes_utilisateur` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_likes_reponse` FOREIGN KEY (`reponse_id`) REFERENCES `reponses_forum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DONNÉES INITIALES
-- ============================================================

-- Administrateur par défaut (mot de passe: Admin@2024)
INSERT INTO `utilisateurs` (`nom`, `prenom`, `email`, `mot_de_passe`, `role`, `statut`) VALUES
('Admin', 'Super', 'admin@actuevents.com', '$2y$10$8K1p/a0dL1KlGMQS7gC1jeYFp8U9kVaQnhKMn8TNRGOj3KzP1bCi2', 'admin', 'actif');

-- Rubriques par défaut
INSERT INTO `rubriques` (`nom`, `slug`, `description`, `couleur`, `icone`, `ordre`) VALUES
('Entrepreneuriat', 'entrepreneuriat', 'Forum et articles sur l\'entrepreneuriat et la création d\'entreprise', '#6C63FF', 'fa-rocket', 1),
('Technologie', 'technologie', 'Innovations technologiques et transformation digitale', '#00D4AA', 'fa-microchip', 2),
('Culture', 'culture', 'Événements culturels, arts et patrimoine', '#FF6B6B', 'fa-palette', 3),
('Formation', 'formation', 'Séminaires, ateliers et formations professionnelles', '#FFB84D', 'fa-graduation-cap', 4),
('Networking', 'networking', 'Rencontres professionnelles et réseautage', '#4ECDC4', 'fa-handshake', 5),
('Conférences', 'conferences', 'Conférences et panels de discussion', '#A855F7', 'fa-microphone', 6);

COMMIT;
