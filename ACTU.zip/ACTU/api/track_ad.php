<?php
/**
 * API - Tracking publicités (impressions/clics)
 */
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$adId = intval($data['ad_id'] ?? 0);
$action = $data['action'] ?? 'impression';

if (!$adId) {
    echo json_encode(['success' => false]);
    exit;
}

if ($action === 'click') {
    $pdo->prepare("UPDATE publicites SET clics = clics + 1 WHERE id = ?")->execute([$adId]);
} else {
    $pdo->prepare("UPDATE publicites SET impressions = impressions + 1 WHERE id = ?")->execute([$adId]);
}

echo json_encode(['success' => true]);
