<?php
/**
 * API - Like/Unlike une réponse forum
 */
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Méthode non autorisée']);
    exit;
}

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Non connecté']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$replyId = intval($data['reply_id'] ?? 0);

if (!$replyId) {
    echo json_encode(['success' => false, 'error' => 'ID invalide']);
    exit;
}

// Vérifier si déjà liké
$check = $pdo->prepare("SELECT id FROM likes_forum WHERE utilisateur_id = ? AND reponse_id = ?");
$check->execute([$_SESSION['user_id'], $replyId]);

if ($check->fetch()) {
    $pdo->prepare("DELETE FROM likes_forum WHERE utilisateur_id = ? AND reponse_id = ?")
        ->execute([$_SESSION['user_id'], $replyId]);
    $pdo->prepare("UPDATE reponses_forum SET likes = GREATEST(likes - 1, 0) WHERE id = ?")
        ->execute([$replyId]);
} else {
    $pdo->prepare("INSERT INTO likes_forum (utilisateur_id, reponse_id) VALUES (?, ?)")
        ->execute([$_SESSION['user_id'], $replyId]);
    $pdo->prepare("UPDATE reponses_forum SET likes = likes + 1 WHERE id = ?")
        ->execute([$replyId]);
}

$likes = $pdo->prepare("SELECT likes FROM reponses_forum WHERE id = ?");
$likes->execute([$replyId]);

echo json_encode(['success' => true, 'likes' => $likes->fetchColumn()]);
