# ACTU Events Magazine

## 🚀 Site complet d'actualités et de gestion d'événements

### 📋 Fonctionnalités

1. **Page d'accueil** - Affichage des articles par rubrique/thématique avec article mis en avant
2. **Forum interactif** - Discussions thématiques avec upload d'images/vidéos
3. **Tableau de bord statistiques** - Suivi des publications, participations par thématique
4. **Tableau de bord éditorial** - Gestion articles, rubriques, forums, publicités partenaires

### 🛠 Technologies

- **Frontend** : HTML5, CSS3 (variables CSS, glassmorphism, dark mode), JavaScript ES6
- **Backend** : PHP 7.4+ (PDO, sessions, CSRF protection)
- **Base de données** : MySQL 5.7+ (InnoDB, Foreign Keys)
- **Librairies** : Font Awesome 6.5, Chart.js 4.4, Google Fonts (Inter, Playfair Display)

### 📁 Structure du projet

```
ACTU/
├── admin/                  # Tableau de bord administrateur
│   ├── index.php          # Dashboard principal + stats
│   ├── articles.php       # Gestion des articles (CRUD)
│   ├── article_edit.php   # Éditeur d'article
│   ├── rubriques.php      # Gestion des rubriques
│   ├── forums_admin.php   # Gestion des forums
│   ├── publicites.php     # Gestion des publicités partenaires
│   ├── utilisateurs.php   # Gestion des utilisateurs
│   ├── statistiques.php   # Statistiques détaillées
│   └── sidebar.php        # Navigation admin
├── api/                   # Endpoints API
│   ├── like.php           # Like/unlike forum
│   └── track_ad.php       # Tracking publicités
├── assets/
│   ├── css/style.css      # Feuille de style complète
│   └── img/               # Images du site
├── database/
│   └── schema.sql         # Schéma SQL complet
├── includes/
│   ├── header.php         # En-tête commun
│   └── footer.php         # Pied de page commun
├── uploads/               # Fichiers uploadés
│   ├── articles/
│   ├── avatars/
│   ├── forum/
│   └── publicites/
├── config.php             # Configuration (DB, site, sécurité)
├── index.php              # Page d'accueil
├── article.php            # Page article individuel
├── rubrique.php           # Articles par rubrique
├── forum.php              # Forum principal
├── forum_sujet.php        # Sujets d'un forum
├── forum_discussion.php   # Discussion + réponses
├── forum_nouveau_sujet.php # Création de sujet
├── connexion.php          # Page de connexion
├── inscription.php        # Page d'inscription
├── deconnexion.php        # Déconnexion
├── profil.php             # Profil utilisateur
├── newsletter.php         # Inscription newsletter
├── 404.php                # Page d'erreur 404
├── .htaccess              # Configuration Apache
└── README.md              # Ce fichier
```

### ⚙️ Installation sur LWS

#### 1. Base de données
1. Connectez-vous à votre panneau LWS → phpMyAdmin
2. Créez une base de données `actu_events`
3. Importez le fichier `database/schema.sql`

#### 2. Configuration
1. Ouvrez `config.php`
2. Modifiez les constantes de connexion :
   ```php
   define('DB_HOST', 'localhost');      // Hôte fourni par LWS
   define('DB_NAME', 'actu_events');    // Nom de votre base
   define('DB_USER', 'votre_user');     // Utilisateur MySQL LWS
   define('DB_PASS', 'votre_mdp');      // Mot de passe MySQL
   ```
3. Modifiez l'URL du site :
   ```php
   define('SITE_URL', 'https://votre-domaine.com');
   ```
4. Changez la clé secrète :
   ```php
   define('SECRET_KEY', 'votre_cle_unique_et_secrete');
   ```

#### 3. Upload des fichiers
1. Uploadez tout le contenu du dossier ACTU à la racine de votre hébergement via FTP
2. Vérifiez les permissions des dossiers `uploads/` : chmod 755 ou 775

#### 4. Connexion admin
- **Email** : admin@actuevents.com
- **Mot de passe** : Admin@2024
- ⚠️ **Changez le mot de passe immédiatement après la première connexion !**

### 🔒 Sécurité intégrée

- Protection CSRF sur tous les formulaires
- Hachage bcrypt des mots de passe
- Requêtes préparées PDO (anti injection SQL)
- Sanitization des entrées utilisateur
- Headers de sécurité (X-Frame-Options, X-XSS-Protection)
- Upload sécurisé (vérification MIME, taille max)
- Protection des fichiers sensibles via .htaccess

### 📊 Base de données

Tables principales :
- `utilisateurs` - Comptes utilisateurs avec rôles
- `rubriques` - Catégories/thématiques
- `articles` - Articles et événements
- `forums` - Forums de discussion
- `sujets_forum` - Sujets/threads
- `reponses_forum` - Réponses aux sujets
- `medias_forum` - Fichiers joints (images, vidéos)
- `commentaires` - Commentaires sur articles
- `publicites` - Bannières publicitaires partenaires
- `statistiques_visites` - Tracking des visites
- `newsletters` - Abonnés newsletter
- `likes_forum` - Likes des réponses
- `tags` / `article_tags` - Système de tags

### 📝 Licence

Projet développé sur mesure. Tous droits réservés.
