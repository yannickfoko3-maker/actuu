<?php
/** Newsletter subscription handler */
require_once __DIR__ . '/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.'); redirect(SITE_URL . '/');
    }
    $email = trim($_POST['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        setFlash('error', 'Email invalide.'); redirect(SITE_URL . '/');
    }
    $check = $pdo->prepare("SELECT id FROM newsletters WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) {
        setFlash('info', 'Vous êtes déjà inscrit à la newsletter !');
    } else {
        $pdo->prepare("INSERT INTO newsletters (email) VALUES (?)")->execute([$email]);
        setFlash('success', 'Inscription à la newsletter réussie !');
    }
}
redirect(SITE_URL . '/');
