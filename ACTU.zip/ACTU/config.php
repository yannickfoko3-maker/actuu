<?php
/**
 * ACTU EVENTS MAGAZINE - Configuration de la base de données
 * Modifier ces valeurs selon votre hébergement LWS
 */

// ============================================================
// CONFIGURATION BASE DE DONNÉES
// ============================================================
define('DB_HOST', 'sql210.infinityfree.com');          // Hôte MySQL (LWS: souvent localhost)
define('DB_NAME', 'if0_43217089_actu_events');       // Nom de la base de données
define('DB_USER', 'if0_43217089');              // Utilisateur MySQL
define('DB_PASS', '');                  // Mot de passe MySQL
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// CONFIGURATION DU SITE
// ============================================================
define('SITE_URL', 'http://localhost/ACTU');  // URL du site (sans / final)
define('SITE_NAME', 'ACTU Events Magazine');
define('SITE_DESCRIPTION', 'Votre magazine d\'actualités et d\'événements');
define('SITE_EMAIL', 'contact@actuevents.com');

// ============================================================
// CONFIGURATION DES UPLOADS
// ============================================================
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10 Mo
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/webm', 'video/ogg']);
define('ALLOWED_DOC_TYPES', ['application/pdf', 'application/msword']);

// ============================================================
// CONFIGURATION DE SÉCURITÉ
// ============================================================
define('SECRET_KEY', 'CHANGEZ_CETTE_CLE_SECRETE_EN_PRODUCTION_2024');
define('SESSION_LIFETIME', 3600 * 24); // 24 heures
define('CSRF_TOKEN_LIFETIME', 3600);   // 1 heure

// ============================================================
// PAGINATION
// ============================================================
define('ARTICLES_PER_PAGE', 12);
define('FORUM_TOPICS_PER_PAGE', 15);
define('FORUM_REPLIES_PER_PAGE', 20);
define('COMMENTS_PER_PAGE', 10);

// ============================================================
// TIMEZONE
// ============================================================
date_default_timezone_set('Africa/Abidjan');

// ============================================================
// SESSION
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}

// ============================================================
// CONNEXION PDO
// ============================================================
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

// ============================================================
// FONCTIONS UTILITAIRES
// ============================================================

/**
 * Générer un slug à partir d'un texte
 */
function generateSlug($text) {
    $text = transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()', $text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

/**
 * Nettoyer les entrées utilisateur
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Générer un token CSRF
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token']) || time() > ($_SESSION['csrf_token_time'] ?? 0) + CSRF_TOKEN_LIFETIME) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * Vérifier un token CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Vérifier si l'utilisateur est connecté
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    return isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
}

/**
 * Vérifier si l'utilisateur est éditeur ou plus
 */
function isEditor() {
    return isLoggedIn() && in_array($_SESSION['user_role'] ?? '', ['admin', 'editeur']);
}

/**
 * Rediriger vers une URL
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Message flash
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Tronquer un texte
 */
function truncateText($text, $length = 150) {
    $text = strip_tags($text);
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

/**
 * Formater une date en français
 */
function formatDate($date, $format = 'long') {
    $mois = ['', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
    $moisComplet = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
    $timestamp = strtotime($date);
    
    if ($format === 'short') {
        return date('d', $timestamp) . ' ' . $mois[(int)date('n', $timestamp)] . ' ' . date('Y', $timestamp);
    }
    if ($format === 'relative') {
        $diff = time() - $timestamp;
        if ($diff < 60) return 'À l\'instant';
        if ($diff < 3600) return floor($diff / 60) . ' min';
        if ($diff < 86400) return floor($diff / 3600) . 'h';
        if ($diff < 604800) return floor($diff / 86400) . 'j';
        return date('d', $timestamp) . ' ' . $mois[(int)date('n', $timestamp)] . ' ' . date('Y', $timestamp);
    }
    return date('d', $timestamp) . ' ' . $moisComplet[(int)date('n', $timestamp)] . ' ' . date('Y', $timestamp);
}

/**
 * Upload de fichier sécurisé
 */
function uploadFile($file, $subdir = 'general') {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Erreur lors de l\'upload'];
    }

    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'error' => 'Fichier trop volumineux (max 10 Mo)'];
    }

    $mime = mime_content_type($file['tmp_name']);
    $allowedTypes = array_merge(ALLOWED_IMAGE_TYPES, ALLOWED_VIDEO_TYPES, ALLOWED_DOC_TYPES);
    
    if (!in_array($mime, $allowedTypes)) {
        return ['success' => false, 'error' => 'Type de fichier non autorisé'];
    }

    $dir = UPLOAD_DIR . $subdir . '/';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . strtolower($ext);
    $filepath = $dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return [
            'success' => true,
            'filename' => $filename,
            'path' => $subdir . '/' . $filename,
            'mime' => $mime,
            'size' => $file['size']
        ];
    }

    return ['success' => false, 'error' => 'Impossible de sauvegarder le fichier'];
}

/**
 * Enregistrer une visite
 */
function logVisit($page) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO statistiques_visites (page, ip_visiteur, user_agent, utilisateur_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $page,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
            $_SESSION['user_id'] ?? null
        ]);
    } catch (Exception $e) {
        // Silently fail
    }
}
