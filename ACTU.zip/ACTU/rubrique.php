<?php
/**
 * ACTU EVENTS MAGAZINE - Page rubrique/catégorie
 */
require_once __DIR__ . '/config.php';

$slug = $_GET['slug'] ?? '';
if (empty($slug)) { redirect(SITE_URL . '/'); }

$stmt = $pdo->prepare("SELECT * FROM rubriques WHERE slug = ? AND statut = 'actif'");
$stmt->execute([$slug]);
$rubrique = $stmt->fetch();

if (!$rubrique) {
    setFlash('error', 'Rubrique introuvable.');
    redirect(SITE_URL . '/');
}

$currentRubrique = $slug;
$pageTitle = $rubrique['nom'];
logVisit('rubrique-' . $rubrique['id']);

$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * ARTICLES_PER_PAGE;

$stmtTotal = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE rubrique_id = ? AND statut = 'publie'");
$stmtTotal->execute([$rubrique['id']]);
$totalArticles = $stmtTotal->fetchColumn();
$totalPages = ceil($totalArticles / ARTICLES_PER_PAGE);

$stmtArticles = $pdo->prepare("
    SELECT a.*, u.prenom, u.nom AS auteur_nom, u.avatar
    FROM articles a
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE a.rubrique_id = ? AND a.statut = 'publie'
    ORDER BY a.date_publication DESC
    LIMIT ? OFFSET ?
");
$stmtArticles->execute([$rubrique['id'], ARTICLES_PER_PAGE, $offset]);
$articles = $stmtArticles->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="container">
        <div class="hero-subtitle" style="background: <?= $rubrique['couleur'] ?>15; border-color: <?= $rubrique['couleur'] ?>30; color: <?= $rubrique['couleur'] ?>;">
            <i class="fas <?= $rubrique['icone'] ?>"></i> Rubrique
        </div>
        <h1 class="hero-title"><?= sanitize($rubrique['nom']) ?></h1>
        <p class="hero-description"><?= sanitize($rubrique['description'] ?? '') ?></p>
        <p class="text-muted mt-1"><?= $totalArticles ?> article<?= $totalArticles > 1 ? 's' : '' ?></p>
    </div>
</section>

<section class="section" style="padding-top: 0;">
    <div class="container">
        <?php if (empty($articles)): ?>
        <div class="card" style="padding: var(--spacing-2xl); text-align: center;">
            <i class="fas fa-newspaper" style="font-size: 3rem; color: var(--text-muted); margin-bottom: var(--spacing-md);"></i>
            <h3>Aucun article dans cette rubrique</h3>
            <a href="<?= SITE_URL ?>/" class="btn btn-primary mt-2">Retour à l'accueil</a>
        </div>
        <?php else: ?>
        <div class="grid grid-articles">
            <?php foreach ($articles as $art): ?>
            <article class="card fade-in-up">
                <div class="card-image">
                    <img src="<?= $art['image_principale'] ? UPLOAD_URL . 'articles/' . sanitize($art['image_principale']) : SITE_URL . '/assets/img/placeholder.jpg' ?>" 
                         alt="<?= sanitize($art['titre']) ?>" loading="lazy">
                </div>
                <div class="card-body">
                    <div class="card-meta">
                        <span><i class="far fa-calendar"></i> <?= formatDate($art['date_publication'], 'short') ?></span>
                        <span><i class="far fa-eye"></i> <?= number_format($art['vues']) ?></span>
                    </div>
                    <h3 class="card-title">
                        <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>"><?= sanitize($art['titre']) ?></a>
                    </h3>
                    <p class="card-excerpt"><?= truncateText($art['extrait'] ?? $art['contenu']) ?></p>
                    <div class="card-footer">
                        <div class="card-author">
                            <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($art['avatar']) ?>" alt="" class="card-author-avatar"
                                 onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                            <span class="card-author-name"><?= sanitize($art['prenom']) ?></span>
                        </div>
                        <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>" class="btn btn-ghost btn-sm">Lire <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
        <nav class="pagination">
            <?php if ($page > 1): ?><a href="?slug=<?= $slug ?>&page=<?= $page - 1 ?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                <?php if ($i == $page): ?><span class="active"><?= $i ?></span>
                <?php else: ?><a href="?slug=<?= $slug ?>&page=<?= $i ?>"><?= $i ?></a><?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?><a href="?slug=<?= $slug ?>&page=<?= $page + 1 ?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
        </nav>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
