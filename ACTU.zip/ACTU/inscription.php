<?php
/**
 * ACTU EVENTS MAGAZINE - Inscription
 */
$pageTitle = 'Inscription';
require_once __DIR__ . '/config.php';

if (isLoggedIn()) { redirect(SITE_URL . '/'); }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Token de sécurité invalide.';
    }

    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($nom) || empty($prenom) || empty($email) || empty($password)) {
        $errors[] = 'Tous les champs sont obligatoires.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Adresse email invalide.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Le mot de passe doit contenir au moins 6 caractères.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Les mots de passe ne correspondent pas.';
    }

    // Vérifier si l'email existe déjà
    if (empty($errors)) {
        $check = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'Cette adresse email est déjà utilisée.';
        }
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, statut) VALUES (?, ?, ?, ?, 'utilisateur', 'actif')");
        $stmt->execute([$nom, $prenom, $email, $hash]);

        $userId = $pdo->lastInsertId();
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_nom'] = $nom;
        $_SESSION['user_prenom'] = $prenom;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_role'] = 'utilisateur';

        setFlash('success', 'Bienvenue ' . sanitize($prenom) . ' ! Votre compte a été créé avec succès.');
        redirect(SITE_URL . '/');
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <a href="<?= SITE_URL ?>/" class="logo" style="justify-content: center; margin-bottom: var(--spacing-xl);">
            <span class="logo-icon">AE</span>
            ACTU Events
        </a>
        
        <h1 class="auth-title">Créer un compte</h1>
        <p class="auth-subtitle">Rejoignez la communauté et participez aux discussions</p>

        <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                <?php foreach ($errors as $err): ?>
                <p><?= sanitize($err) ?></p>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-md);">
                <div class="form-group">
                    <label class="form-label">Nom</label>
                    <input type="text" name="nom" class="form-control" placeholder="Votre nom" 
                           value="<?= sanitize($nom ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Prénom</label>
                    <input type="text" name="prenom" class="form-control" placeholder="Votre prénom" 
                           value="<?= sanitize($prenom ?? '') ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="votre@email.com" 
                       value="<?= sanitize($email ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Mot de passe</label>
                <input type="password" name="password" class="form-control" placeholder="Minimum 6 caractères" required>
            </div>

            <div class="form-group">
                <label class="form-label">Confirmer le mot de passe</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirmez votre mot de passe" required>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">
                <i class="fas fa-user-plus"></i> Créer mon compte
            </button>
        </form>

        <p class="auth-footer">
            Déjà inscrit ? <a href="<?= SITE_URL ?>/connexion.php">Se connecter</a>
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
