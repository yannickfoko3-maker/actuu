<?php
/**
 * ACTU EVENTS MAGAZINE - Liste des sujets d'un forum
 */
$currentPage = 'forum';
require_once __DIR__ . '/config.php';

$slug = $_GET['slug'] ?? '';
if (empty($slug)) { redirect(SITE_URL . '/forum.php'); }

$stmt = $pdo->prepare("
    SELECT f.*, r.nom AS rubrique_nom, r.couleur AS rubrique_couleur, r.icone AS rubrique_icone
    FROM forums f
    LEFT JOIN rubriques r ON f.rubrique_id = r.id
    WHERE f.slug = ?
");
$stmt->execute([$slug]);
$forum = $stmt->fetch();

if (!$forum) {
    setFlash('error', 'Forum introuvable.');
    redirect(SITE_URL . '/forum.php');
}

$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * FORUM_TOPICS_PER_PAGE;

$stmtTopics = $pdo->prepare("
    SELECT sf.*, u.prenom, u.nom AS auteur_nom, u.avatar,
           (SELECT COUNT(*) FROM reponses_forum WHERE sujet_id = sf.id AND statut = 'actif') AS nb_reponses
    FROM sujets_forum sf
    JOIN utilisateurs u ON sf.auteur_id = u.id
    WHERE sf.forum_id = ?
    ORDER BY sf.epingle DESC, sf.date_derniere_reponse DESC, sf.date_creation DESC
    LIMIT ? OFFSET ?
");
$stmtTopics->execute([$forum['id'], FORUM_TOPICS_PER_PAGE, $offset]);
$topics = $stmtTopics->fetchAll();

$totalTopics = $pdo->prepare("SELECT COUNT(*) FROM sujets_forum WHERE forum_id = ?");
$totalTopics->execute([$forum['id']]);
$totalPages = ceil($totalTopics->fetchColumn() / FORUM_TOPICS_PER_PAGE);

$pageTitle = $forum['titre'] . ' - Forum';
require_once __DIR__ . '/includes/header.php';
?>

<section style="padding-top: 90px;">
    <div class="container">
        <div style="display: flex; align-items: center; gap: var(--spacing-sm); font-size: 0.85rem; color: var(--text-muted); margin-bottom: var(--spacing-xl);">
            <a href="<?= SITE_URL ?>/forum.php">Forum</a>
            <i class="fas fa-chevron-right" style="font-size: 0.6rem;"></i>
            <span style="color: var(--text-primary);"><?= sanitize($forum['titre']) ?></span>
        </div>

        <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: var(--spacing-lg); margin-bottom: var(--spacing-2xl); flex-wrap: wrap;">
            <div>
                <h1 style="font-family: var(--font-serif); font-size: 2rem; font-weight: 700; margin-bottom: var(--spacing-sm);">
                    <i class="fas <?= $forum['rubrique_icone'] ?? 'fa-comments' ?>" style="color: <?= $forum['rubrique_couleur'] ?? 'var(--accent-primary)' ?>;"></i>
                    <?= sanitize($forum['titre']) ?>
                </h1>
                <p style="color: var(--text-secondary); max-width: 600px;"><?= sanitize($forum['description'] ?? '') ?></p>
            </div>
            <?php if (isLoggedIn()): ?>
            <a href="<?= SITE_URL ?>/forum_nouveau_sujet.php?forum=<?= $forum['id'] ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nouveau sujet
            </a>
            <?php endif; ?>
        </div>

        <?php if (empty($topics)): ?>
        <div class="card" style="padding: var(--spacing-2xl); text-align: center;">
            <i class="fas fa-comments" style="font-size: 3rem; color: var(--text-muted); margin-bottom: var(--spacing-md);"></i>
            <h3>Aucun sujet pour le moment</h3>
            <p class="text-muted">Soyez le premier à lancer une discussion !</p>
            <?php if (isLoggedIn()): ?>
            <a href="<?= SITE_URL ?>/forum_nouveau_sujet.php?forum=<?= $forum['id'] ?>" class="btn btn-primary mt-2">
                <i class="fas fa-plus"></i> Créer un sujet
            </a>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <?php foreach ($topics as $topic): ?>
        <div class="topic-item fade-in-up">
            <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($topic['avatar']) ?>" alt="" class="topic-avatar"
                 onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
            <div class="topic-info">
                <div class="topic-title">
                    <?php if ($topic['epingle']): ?><i class="fas fa-thumbtack text-accent"></i> <?php endif; ?>
                    <?php if ($topic['statut'] === 'resolu'): ?><i class="fas fa-check-circle text-success"></i> <?php endif; ?>
                    <a href="<?= SITE_URL ?>/forum_discussion.php?id=<?= $topic['id'] ?>"><?= sanitize($topic['titre']) ?></a>
                </div>
                <div class="topic-meta">
                    par <strong><?= sanitize($topic['prenom'] . ' ' . $topic['auteur_nom']) ?></strong>
                    &middot; <?= formatDate($topic['date_creation'], 'relative') ?>
                </div>
            </div>
            <div class="topic-stats">
                <div>
                    <strong><?= $topic['nb_reponses'] ?></strong>
                    <span class="text-muted" style="font-size: 0.75rem;">réponses</span>
                </div>
                <div>
                    <strong><?= number_format($topic['vues']) ?></strong>
                    <span class="text-muted" style="font-size: 0.75rem;">vues</span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if ($totalPages > 1): ?>
        <nav class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                <span class="active"><?= $i ?></span>
                <?php else: ?>
                <a href="?slug=<?= $slug ?>&page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </nav>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
