<?php
/**
 * ACTU EVENTS MAGAZINE - Forum principal
 * Liste des forums et sujets récents
 */
$currentPage = 'forum';
$pageTitle = 'Forum';
require_once __DIR__ . '/config.php';
logVisit('forum');

// Récupérer tous les forums
$stmtForums = $pdo->query("
    SELECT f.*, r.nom AS rubrique_nom, r.couleur AS rubrique_couleur, r.icone AS rubrique_icone,
           u.prenom, u.nom AS auteur_nom,
           (SELECT COUNT(*) FROM sujets_forum sf WHERE sf.forum_id = f.id) AS nb_sujets,
           (SELECT COUNT(*) FROM reponses_forum rf 
            JOIN sujets_forum sf2 ON rf.sujet_id = sf2.id 
            WHERE sf2.forum_id = f.id) AS nb_messages
    FROM forums f
    LEFT JOIN rubriques r ON f.rubrique_id = r.id
    JOIN utilisateurs u ON f.createur_id = u.id
    WHERE f.statut = 'ouvert'
    ORDER BY f.date_dernier_message DESC, f.date_creation DESC
");
$forums = $stmtForums->fetchAll();

// Derniers sujets actifs
$stmtRecent = $pdo->query("
    SELECT sf.*, f.titre AS forum_titre, f.slug AS forum_slug,
           u.prenom, u.nom AS auteur_nom, u.avatar,
           (SELECT COUNT(*) FROM reponses_forum WHERE sujet_id = sf.id) AS nb_reponses
    FROM sujets_forum sf
    JOIN forums f ON sf.forum_id = f.id
    JOIN utilisateurs u ON sf.auteur_id = u.id
    WHERE sf.statut = 'ouvert'
    ORDER BY sf.date_derniere_reponse DESC, sf.date_creation DESC
    LIMIT 10
");
$recentTopics = $stmtRecent->fetchAll();

// Statistiques globales
$statsForums = $pdo->query("SELECT COUNT(*) FROM forums WHERE statut = 'ouvert'")->fetchColumn();
$statsSujets = $pdo->query("SELECT COUNT(*) FROM sujets_forum")->fetchColumn();
$statsMessages = $pdo->query("SELECT COUNT(*) FROM reponses_forum")->fetchColumn();
$statsMembres = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE statut = 'actif'")->fetchColumn();

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Forum -->
<section class="hero">
    <div class="container">
        <div class="hero-subtitle">
            <i class="fas fa-comments"></i> Espace de discussion
        </div>
        <h1 class="hero-title">
            Le <span class="gradient-text">Forum</span><br>de la communauté
        </h1>
        <p class="hero-description">
            Participez aux discussions, partagez vos expériences et échangez avec les autres participants des événements.
        </p>
        <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-xl); flex-wrap: wrap;">
            <?php if (isLoggedIn()): ?>
            <a href="<?= SITE_URL ?>/forum_nouveau_sujet.php" class="btn btn-primary btn-lg">
                <i class="fas fa-plus"></i> Nouveau sujet
            </a>
            <?php else: ?>
            <a href="<?= SITE_URL ?>/connexion.php" class="btn btn-primary btn-lg">
                <i class="fas fa-sign-in-alt"></i> Se connecter pour participer
            </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Statistiques forum -->
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="grid grid-4">
            <div class="stat-card">
                <div class="stat-card-icon" style="background: rgba(108,99,255,0.1); color: var(--accent-primary);">
                    <i class="fas fa-layer-group"></i>
                </div>
                <div class="stat-card-value"><?= number_format($statsForums) ?></div>
                <div class="stat-card-label">Forums</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon" style="background: rgba(0,212,170,0.1); color: var(--success);">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stat-card-value"><?= number_format($statsSujets) ?></div>
                <div class="stat-card-label">Sujets</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon" style="background: rgba(168,85,247,0.1); color: var(--accent-secondary);">
                    <i class="fas fa-reply-all"></i>
                </div>
                <div class="stat-card-value"><?= number_format($statsMessages) ?></div>
                <div class="stat-card-label">Réponses</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon" style="background: rgba(255,184,77,0.1); color: var(--warning);">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-card-value"><?= number_format($statsMembres) ?></div>
                <div class="stat-card-label">Membres</div>
            </div>
        </div>
    </div>
</section>

<!-- Liste des forums -->
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Forums <span class="accent">thématiques</span></h2>
        </div>

        <?php if (empty($forums)): ?>
        <div class="card" style="padding: var(--spacing-2xl); text-align: center;">
            <i class="fas fa-comments" style="font-size: 3rem; color: var(--text-muted); margin-bottom: var(--spacing-md);"></i>
            <h3>Aucun forum pour le moment</h3>
            <p class="text-muted">Les forums seront créés par l'administrateur.</p>
        </div>
        <?php else: ?>
        <?php foreach ($forums as $forum): ?>
        <div class="forum-card fade-in-up">
            <div class="forum-card-icon" style="background: <?= ($forum['rubrique_couleur'] ?? '#6C63FF') ?>15; color: <?= $forum['rubrique_couleur'] ?? '#6C63FF' ?>;">
                <i class="fas <?= $forum['rubrique_icone'] ?? 'fa-comments' ?>"></i>
            </div>
            <div class="forum-card-content">
                <h3 class="forum-card-title">
                    <a href="<?= SITE_URL ?>/forum_sujet.php?slug=<?= $forum['slug'] ?>">
                        <?= sanitize($forum['titre']) ?>
                    </a>
                </h3>
                <p class="forum-card-desc"><?= truncateText($forum['description'] ?? '', 120) ?></p>
                <div class="forum-card-stats">
                    <span><i class="fas fa-comments"></i> <?= number_format($forum['nb_sujets']) ?> sujets</span>
                    <span><i class="fas fa-reply"></i> <?= number_format($forum['nb_messages']) ?> messages</span>
                    <?php if ($forum['rubrique_nom']): ?>
                    <span class="tag" style="background: <?= $forum['rubrique_couleur'] ?>20; color: <?= $forum['rubrique_couleur'] ?>; padding: 2px 8px;">
                        <?= sanitize($forum['rubrique_nom']) ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div style="flex-shrink: 0;">
                <a href="<?= SITE_URL ?>/forum_sujet.php?slug=<?= $forum['slug'] ?>" class="btn btn-secondary btn-sm">
                    Voir <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<!-- Sujets récents -->
<?php if (!empty($recentTopics)): ?>
<section class="section" style="padding-top: 0;">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Discussions <span class="accent">récentes</span></h2>
        </div>

        <?php foreach ($recentTopics as $topic): ?>
        <div class="topic-item">
            <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($topic['avatar']) ?>" alt="" class="topic-avatar"
                 onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
            <div class="topic-info">
                <div class="topic-title">
                    <?php if ($topic['epingle']): ?><i class="fas fa-thumbtack text-accent"></i> <?php endif; ?>
                    <a href="<?= SITE_URL ?>/forum_discussion.php?id=<?= $topic['id'] ?>">
                        <?= sanitize($topic['titre']) ?>
                    </a>
                </div>
                <div class="topic-meta">
                    par <strong><?= sanitize($topic['prenom'] . ' ' . $topic['auteur_nom']) ?></strong>
                    dans <a href="<?= SITE_URL ?>/forum_sujet.php?slug=<?= $topic['forum_slug'] ?>"><?= sanitize($topic['forum_titre']) ?></a>
                    &middot; <?= formatDate($topic['date_creation'], 'relative') ?>
                </div>
            </div>
            <div class="topic-stats">
                <div>
                    <strong><?= $topic['nb_reponses'] ?></strong>
                    <span class="text-muted" style="font-size: 0.75rem;">réponses</span>
                </div>
                <div>
                    <strong><?= number_format($topic['vues']) ?></strong>
                    <span class="text-muted" style="font-size: 0.75rem;">vues</span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
