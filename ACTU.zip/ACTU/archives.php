<?php
/**
 * ACTU EVENTS MAGAZINE - Archives (tous les articles)
 */
$currentPage = 'archives';
$pageTitle = 'Archives';
require_once __DIR__ . '/config.php';
logVisit('archives');

$search = trim($_GET['q'] ?? '');
$rubFilter = intval($_GET['rubrique'] ?? 0);
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * ARTICLES_PER_PAGE;

$where = "a.statut = 'publie'";
$params = [];

if (!empty($search)) {
    $where .= " AND (a.titre LIKE ? OR a.contenu LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($rubFilter) {
    $where .= " AND a.rubrique_id = ?";
    $params[] = $rubFilter;
}

$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM articles a WHERE $where");
$stmtCount->execute($params);
$total = $stmtCount->fetchColumn();
$totalPages = ceil($total / ARTICLES_PER_PAGE);

$stmtArticles = $pdo->prepare("
    SELECT a.*, r.nom AS rubrique_nom, r.slug AS rubrique_slug, r.couleur AS rubrique_couleur,
           u.prenom, u.nom AS auteur_nom, u.avatar
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE $where
    ORDER BY a.date_publication DESC
    LIMIT " . ARTICLES_PER_PAGE . " OFFSET $offset
");
$stmtArticles->execute($params);
$articles = $stmtArticles->fetchAll();

$rubriques = $pdo->query("SELECT id, nom FROM rubriques WHERE statut = 'actif' ORDER BY nom")->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="container">
        <h1 class="hero-title">Toutes les <span class="gradient-text">actualités</span></h1>
        <p class="hero-description">Parcourez l'ensemble de nos articles et retrouvez les événements passés.</p>

        <form method="GET" style="display:flex;gap:var(--spacing-sm);margin-top:var(--spacing-xl);max-width:600px;flex-wrap:wrap;">
            <input type="text" name="q" class="form-control" placeholder="Rechercher un article..." value="<?= sanitize($search) ?>" style="flex:1;min-width:200px;">
            <select name="rubrique" class="form-control" style="width:auto;min-width:160px;">
                <option value="0">Toutes rubriques</option>
                <?php foreach ($rubriques as $r): ?>
                <option value="<?= $r['id'] ?>" <?= $rubFilter == $r['id'] ? 'selected' : '' ?>><?= sanitize($r['nom']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Rechercher</button>
        </form>
    </div>
</section>

<section class="section" style="padding-top:0;">
    <div class="container">
        <p class="text-muted mb-2"><?= $total ?> article<?= $total > 1 ? 's' : '' ?> trouvé<?= $total > 1 ? 's' : '' ?></p>

        <?php if (empty($articles)): ?>
        <div class="card" style="padding:var(--spacing-2xl);text-align:center;">
            <i class="fas fa-search" style="font-size:3rem;color:var(--text-muted);margin-bottom:var(--spacing-md);"></i>
            <h3>Aucun résultat</h3>
            <p class="text-muted">Essayez d'autres termes de recherche.</p>
        </div>
        <?php else: ?>
        <div class="grid grid-articles">
            <?php foreach ($articles as $art): ?>
            <article class="card fade-in-up">
                <div class="card-image">
                    <img src="<?= $art['image_principale'] ? UPLOAD_URL . 'articles/' . sanitize($art['image_principale']) : SITE_URL . '/assets/img/placeholder.svg' ?>"
                         alt="<?= sanitize($art['titre']) ?>" loading="lazy">
                    <span class="card-badge" style="background:<?= $art['rubrique_couleur'] ?>DD;"><?= sanitize($art['rubrique_nom']) ?></span>
                </div>
                <div class="card-body">
                    <div class="card-meta">
                        <span><i class="far fa-calendar"></i> <?= formatDate($art['date_publication'], 'short') ?></span>
                        <span><i class="far fa-eye"></i> <?= number_format($art['vues']) ?></span>
                    </div>
                    <h3 class="card-title"><a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>"><?= sanitize($art['titre']) ?></a></h3>
                    <p class="card-excerpt"><?= truncateText($art['extrait'] ?? $art['contenu']) ?></p>
                    <div class="card-footer">
                        <div class="card-author">
                            <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($art['avatar']) ?>" alt="" class="card-author-avatar"
                                 onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'">
                            <span class="card-author-name"><?= sanitize($art['prenom']) ?></span>
                        </div>
                        <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>" class="btn btn-ghost btn-sm">Lire <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if ($totalPages > 1): ?>
        <nav class="pagination">
            <?php if ($page > 1): ?><a href="?q=<?= urlencode($search) ?>&rubrique=<?= $rubFilter ?>&page=<?= $page-1 ?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                <?php if ($i == $page): ?><span class="active"><?= $i ?></span>
                <?php else: ?><a href="?q=<?= urlencode($search) ?>&rubrique=<?= $rubFilter ?>&page=<?= $i ?>"><?= $i ?></a><?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?><a href="?q=<?= urlencode($search) ?>&rubrique=<?= $rubFilter ?>&page=<?= $page+1 ?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
        </nav>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
