<?php
/**
 * ACTU EVENTS MAGAZINE - Connexion
 */
$pageTitle = 'Connexion';
require_once __DIR__ . '/config.php';

if (isLoggedIn()) { redirect(SITE_URL . '/'); }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Token de sécurité invalide.';
    }

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $errors[] = 'Veuillez remplir tous les champs.';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ? AND statut = 'actif'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nom'] = $user['nom'];
            $_SESSION['user_prenom'] = $user['prenom'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_avatar'] = $user['avatar'];

            // Mettre à jour la dernière connexion
            $pdo->prepare("UPDATE utilisateurs SET derniere_connexion = NOW() WHERE id = ?")->execute([$user['id']]);

            setFlash('success', 'Bienvenue, ' . sanitize($user['prenom']) . ' !');
            
            // Redirection admin si rôle admin/editeur
            if (in_array($user['role'], ['admin', 'editeur'])) {
                redirect(SITE_URL . '/admin/');
            }
            redirect(SITE_URL . '/');
        } else {
            $errors[] = 'Email ou mot de passe incorrect.';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <a href="<?= SITE_URL ?>/" class="logo" style="justify-content: center; margin-bottom: var(--spacing-xl);">
            <span class="logo-icon">AE</span>
            ACTU Events
        </a>
        
        <h1 class="auth-title">Connexion</h1>
        <p class="auth-subtitle">Accédez à votre espace et rejoignez les discussions</p>

        <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php foreach ($errors as $err): ?>
            <p><?= sanitize($err) ?></p>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="votre@email.com" 
                       value="<?= sanitize($email ?? '') ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Mot de passe</label>
                <input type="password" name="password" class="form-control" placeholder="Votre mot de passe" required>
            </div>

            <div class="form-group" style="display: flex; justify-content: space-between; align-items: center;">
                <label class="form-check">
                    <input type="checkbox" name="remember"> <span style="font-size: 0.85rem; color: var(--text-secondary);">Se souvenir de moi</span>
                </label>
                <a href="#" style="font-size: 0.85rem;">Mot de passe oublié ?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">
                <i class="fas fa-sign-in-alt"></i> Se connecter
            </button>
        </form>

        <p class="auth-footer">
            Pas encore de compte ? <a href="<?= SITE_URL ?>/inscription.php">Créer un compte</a>
        </p>

        <div style="margin-top: var(--spacing-lg); padding: var(--spacing-md); background: rgba(108,99,255,0.08); border-radius: var(--radius-sm); font-size: 0.8rem; color: var(--text-muted); text-align: center;">
            <strong>Compte admin par défaut :</strong><br>
            admin@actuevents.com / Admin@2024
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
