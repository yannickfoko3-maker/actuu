<?php
/**
 * ACTU EVENTS MAGAZINE - Page profil utilisateur
 */
$pageTitle = 'Mon profil';
require_once __DIR__ . '/config.php';

if (!isLoggedIn()) { redirect(SITE_URL . '/connexion.php'); }

$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }

    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $bio = trim($_POST['bio'] ?? '');

    // Upload avatar
    $avatar = $user['avatar'];
    if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($_FILES['avatar'], 'avatars');
        if ($result['success']) {
            $avatar = $result['filename'];
        }
    }

    $pdo->prepare("UPDATE utilisateurs SET nom = ?, prenom = ?, bio = ?, avatar = ? WHERE id = ?")
        ->execute([$nom, $prenom, $bio, $avatar, $_SESSION['user_id']]);

    $_SESSION['user_nom'] = $nom;
    $_SESSION['user_prenom'] = $prenom;
    $_SESSION['user_avatar'] = $avatar;
    setFlash('success', 'Profil mis à jour !');
    redirect($_SERVER['REQUEST_URI']);
}

// Mot de passe
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['mot_de_passe'])) {
        setFlash('error', 'Mot de passe actuel incorrect.');
    } elseif (strlen($new) < 6) {
        setFlash('error', 'Le nouveau mot de passe doit faire au moins 6 caractères.');
    } elseif ($new !== $confirm) {
        setFlash('error', 'Les mots de passe ne correspondent pas.');
    } else {
        $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?")
            ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
        setFlash('success', 'Mot de passe modifié !');
    }
    redirect($_SERVER['REQUEST_URI']);
}

// Statistiques utilisateur
$nbArticles = $pdo->prepare("SELECT COUNT(*) FROM commentaires WHERE auteur_id = ?");
$nbArticles->execute([$_SESSION['user_id']]);
$userComments = $nbArticles->fetchColumn();

$nbForumPosts = $pdo->prepare("SELECT COUNT(*) FROM reponses_forum WHERE auteur_id = ?");
$nbForumPosts->execute([$_SESSION['user_id']]);
$userForumPosts = $nbForumPosts->fetchColumn();

$nbSujets = $pdo->prepare("SELECT COUNT(*) FROM sujets_forum WHERE auteur_id = ?");
$nbSujets->execute([$_SESSION['user_id']]);
$userSujets = $nbSujets->fetchColumn();

require_once __DIR__ . '/includes/header.php';
?>

<section style="padding-top: 100px; padding-bottom: var(--spacing-3xl);">
    <div class="container" style="max-width: 800px;">
        <h1 style="font-family: var(--font-serif); font-size: 1.8rem; margin-bottom: var(--spacing-2xl);">
            <i class="fas fa-user-circle text-accent"></i> Mon profil
        </h1>

        <!-- Statistiques -->
        <div class="grid grid-3" style="margin-bottom: var(--spacing-2xl);">
            <div class="stat-card text-center">
                <div class="stat-card-value" style="font-size: 1.5rem;"><?= $userComments ?></div>
                <div class="stat-card-label">Commentaires</div>
            </div>
            <div class="stat-card text-center">
                <div class="stat-card-value" style="font-size: 1.5rem;"><?= $userSujets ?></div>
                <div class="stat-card-label">Sujets créés</div>
            </div>
            <div class="stat-card text-center">
                <div class="stat-card-value" style="font-size: 1.5rem;"><?= $userForumPosts ?></div>
                <div class="stat-card-label">Messages forum</div>
            </div>
        </div>

        <!-- Profil -->
        <div class="card" style="padding: var(--spacing-xl); margin-bottom: var(--spacing-xl);">
            <h3 style="font-weight: 700; margin-bottom: var(--spacing-lg);">Informations personnelles</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                <div style="text-align: center; margin-bottom: var(--spacing-xl);">
                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($user['avatar']) ?>" alt=""
                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'"
                         style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid var(--accent-primary); margin-bottom: var(--spacing-md);">
                    <div>
                        <label class="btn btn-secondary btn-sm" style="cursor: pointer;">
                            <i class="fas fa-camera"></i> Changer l'avatar
                            <input type="file" name="avatar" accept="image/*" style="display: none;"
                                   onchange="this.closest('form').querySelector('img').src = URL.createObjectURL(this.files[0])">
                        </label>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-md);">
                    <div class="form-group">
                        <label class="form-label">Nom</label>
                        <input type="text" name="nom" class="form-control" value="<?= sanitize($user['nom']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Prénom</label>
                        <input type="text" name="prenom" class="form-control" value="<?= sanitize($user['prenom']) ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" value="<?= sanitize($user['email']) ?>" disabled>
                </div>

                <div class="form-group">
                    <label class="form-label">Biographie</label>
                    <textarea name="bio" class="form-control" rows="3" placeholder="Parlez-nous de vous..."><?= sanitize($user['bio'] ?? '') ?></textarea>
                </div>

                <button type="submit" name="update_profile" class="btn btn-primary">
                    <i class="fas fa-save"></i> Enregistrer
                </button>
            </form>
        </div>

        <!-- Changer mot de passe -->
        <div class="card" style="padding: var(--spacing-xl);">
            <h3 style="font-weight: 700; margin-bottom: var(--spacing-lg);">Changer le mot de passe</h3>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="form-group">
                    <label class="form-label">Mot de passe actuel</label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--spacing-md);">
                    <div class="form-group">
                        <label class="form-label">Nouveau mot de passe</label>
                        <input type="password" name="new_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirmer</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                </div>
                <button type="submit" name="change_password" class="btn btn-secondary">
                    <i class="fas fa-key"></i> Modifier le mot de passe
                </button>
            </form>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
