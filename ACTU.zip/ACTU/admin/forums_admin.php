<?php
/**
 * Admin - Gestion des forums
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'forums';
$pageTitle = 'Forums';

// Suppression
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM forums WHERE id = ?")->execute([intval($_GET['delete'])]);
    setFlash('success', 'Forum supprimé.');
    redirect(SITE_URL . '/admin/forums_admin.php');
}

// Ajout / Modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) { setFlash('error', 'Token invalide.'); redirect($_SERVER['REQUEST_URI']); }

    $id = intval($_POST['id'] ?? 0);
    $titre = trim($_POST['titre'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $rubrique_id = intval($_POST['rubrique_id'] ?? 0) ?: null;
    $statut = $_POST['statut'] ?? 'ouvert';

    if (empty($titre)) {
        setFlash('error', 'Le titre est obligatoire.');
    } else {
        $slug = generateSlug($titre);
        if ($id) {
            $pdo->prepare("UPDATE forums SET titre=?,slug=?,description=?,rubrique_id=?,statut=? WHERE id=?")
                ->execute([$titre, $slug, $description, $rubrique_id, $statut, $id]);
            setFlash('success', 'Forum mis à jour !');
        } else {
            $slug .= '-' . uniqid();
            $pdo->prepare("INSERT INTO forums (titre,slug,description,rubrique_id,createur_id,statut) VALUES (?,?,?,?,?,?)")
                ->execute([$titre, $slug, $description, $rubrique_id, $_SESSION['user_id'], $statut]);
            setFlash('success', 'Forum créé !');
        }
    }
    redirect(SITE_URL . '/admin/forums_admin.php');
}

$editForum = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM forums WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editForum = $stmt->fetch();
}

$forums = $pdo->query("
    SELECT f.*, r.nom AS rubrique_nom, r.couleur,
           (SELECT COUNT(*) FROM sujets_forum WHERE forum_id = f.id) AS nb_sujets,
           (SELECT COUNT(*) FROM reponses_forum rf JOIN sujets_forum sf ON rf.sujet_id = sf.id WHERE sf.forum_id = f.id) AS nb_messages
    FROM forums f
    LEFT JOIN rubriques r ON f.rubrique_id = r.id
    ORDER BY f.date_creation DESC
")->fetchAll();

$rubriques = $pdo->query("SELECT id, nom FROM rubriques WHERE statut = 'actif' ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forums | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><i class="fas fa-comments text-accent"></i> Gestion des forums</h1>
        </div>

        <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
        <?php endif; ?>

        <div class="grid" style="grid-template-columns: 1fr 380px; gap: var(--spacing-xl);">
            <!-- Liste -->
            <div class="chart-container" style="padding:0;overflow:hidden;">
                <table class="data-table">
                    <thead><tr><th>Forum</th><th>Rubrique</th><th>Sujets</th><th>Messages</th><th>Statut</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php if (empty($forums)): ?>
                        <tr><td colspan="6" style="text-align:center;padding:var(--spacing-2xl);color:var(--text-muted);">Aucun forum créé.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($forums as $f): ?>
                        <tr>
                            <td>
                                <div style="font-weight:600;"><?= sanitize($f['titre']) ?></div>
                                <div style="font-size:0.75rem;color:var(--text-muted);"><?= truncateText($f['description'] ?? '', 60) ?></div>
                            </td>
                            <td>
                                <?php if ($f['rubrique_nom']): ?>
                                <span class="tag" style="background:<?= $f['couleur'] ?>20;color:<?= $f['couleur'] ?>;"><?= sanitize($f['rubrique_nom']) ?></span>
                                <?php else: ?>
                                <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $f['nb_sujets'] ?></td>
                            <td><?= $f['nb_messages'] ?></td>
                            <td><span class="tag tag-<?= $f['statut']==='ouvert'?'success':($f['statut']==='ferme'?'danger':'warning') ?>"><?= ucfirst($f['statut']) ?></span></td>
                            <td>
                                <a href="<?= SITE_URL ?>/forum_sujet.php?slug=<?= $f['slug'] ?>" class="btn btn-ghost btn-sm" target="_blank"><i class="fas fa-eye"></i></a>
                                <a href="?edit=<?= $f['id'] ?>" class="btn btn-ghost btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $f['id'] ?>" class="btn btn-ghost btn-sm" style="color:var(--danger);" onclick="return confirm('Supprimer ce forum et tous ses sujets ?');"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Formulaire -->
            <div class="card" style="padding:var(--spacing-lg);">
                <h3 style="font-weight:700;margin-bottom:var(--spacing-lg);font-size:0.95rem;">
                    <?= $editForum ? 'Modifier le forum' : 'Nouveau forum' ?>
                </h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="id" value="<?= $editForum['id'] ?? 0 ?>">

                    <div class="form-group">
                        <label class="form-label">Titre du forum *</label>
                        <input type="text" name="titre" class="form-control" placeholder="Ex: Forum sur l'Entrepreneuriat"
                               value="<?= sanitize($editForum['titre'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Description du forum..."><?= sanitize($editForum['description'] ?? '') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Rubrique associée</label>
                        <select name="rubrique_id" class="form-control">
                            <option value="0">Aucune</option>
                            <?php foreach ($rubriques as $r): ?>
                            <option value="<?= $r['id'] ?>" <?= ($editForum['rubrique_id'] ?? 0) == $r['id'] ? 'selected' : '' ?>>
                                <?= sanitize($r['nom']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Statut</label>
                        <select name="statut" class="form-control">
                            <option value="ouvert" <?= ($editForum['statut'] ?? 'ouvert') === 'ouvert' ? 'selected' : '' ?>>Ouvert</option>
                            <option value="ferme" <?= ($editForum['statut'] ?? '') === 'ferme' ? 'selected' : '' ?>>Fermé</option>
                            <option value="archive" <?= ($editForum['statut'] ?? '') === 'archive' ? 'selected' : '' ?>>Archivé</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save"></i> <?= $editForum ? 'Mettre à jour' : 'Créer le forum' ?>
                    </button>
                    <?php if ($editForum): ?>
                    <a href="<?= SITE_URL ?>/admin/forums_admin.php" class="btn btn-secondary w-100 mt-1">Annuler</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
