<?php
/**
 * ACTU EVENTS MAGAZINE - Tableau de bord administrateur
 * Statistiques globales
 */
require_once __DIR__ . '/../config.php';

if (!isAdmin() && !isEditor()) {
    setFlash('error', 'Accès non autorisé.');
    redirect(SITE_URL . '/connexion.php');
}

$pageTitle = 'Tableau de bord';

// ---- Statistiques globales ----
$totalArticles = $pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();
$articlesPublies = $pdo->query("SELECT COUNT(*) FROM articles WHERE statut = 'publie'")->fetchColumn();
$totalUtilisateurs = $pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
$totalForumMessages = $pdo->query("SELECT COUNT(*) FROM reponses_forum")->fetchColumn();
$totalSujets = $pdo->query("SELECT COUNT(*) FROM sujets_forum")->fetchColumn();
$totalVues = $pdo->query("SELECT COALESCE(SUM(vues), 0) FROM articles")->fetchColumn();
$totalCommentaires = $pdo->query("SELECT COUNT(*) FROM commentaires")->fetchColumn();

// Visites aujourd'hui
$visitesToday = $pdo->query("SELECT COUNT(*) FROM statistiques_visites WHERE DATE(date_visite) = CURDATE()")->fetchColumn();

// Nouveaux membres ce mois
$newMembersMonth = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE MONTH(date_inscription) = MONTH(CURDATE()) AND YEAR(date_inscription) = YEAR(CURDATE())")->fetchColumn();

// Articles par rubrique
$articlesByRubrique = $pdo->query("
    SELECT r.nom, r.couleur, COUNT(a.id) AS nb
    FROM rubriques r
    LEFT JOIN articles a ON a.rubrique_id = r.id AND a.statut = 'publie'
    WHERE r.statut = 'actif'
    GROUP BY r.id ORDER BY nb DESC
")->fetchAll();

// Top contributeurs forum
$topContributors = $pdo->query("
    SELECT u.prenom, u.nom, u.avatar, u.email,
           (SELECT COUNT(*) FROM reponses_forum WHERE auteur_id = u.id) AS nb_reponses,
           (SELECT COUNT(*) FROM sujets_forum WHERE auteur_id = u.id) AS nb_sujets,
           (SELECT COUNT(*) FROM commentaires WHERE auteur_id = u.id) AS nb_commentaires
    FROM utilisateurs u
    WHERE u.statut = 'actif'
    ORDER BY (SELECT COUNT(*) FROM reponses_forum WHERE auteur_id = u.id) + 
             (SELECT COUNT(*) FROM sujets_forum WHERE auteur_id = u.id) DESC
    LIMIT 10
")->fetchAll();

// Derniers articles
$recentArticles = $pdo->query("
    SELECT a.id, a.titre, a.statut, a.vues, a.date_creation, r.nom AS rubrique_nom, r.couleur,
           u.prenom, u.nom AS auteur_nom
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    ORDER BY a.date_creation DESC LIMIT 8
")->fetchAll();

// Statistiques forum par thématique
$forumStats = $pdo->query("
    SELECT f.titre, f.slug,
           (SELECT COUNT(*) FROM sujets_forum WHERE forum_id = f.id) AS nb_sujets,
           (SELECT COUNT(*) FROM reponses_forum rf JOIN sujets_forum sf ON rf.sujet_id = sf.id WHERE sf.forum_id = f.id) AS nb_messages,
           (SELECT COUNT(DISTINCT rf2.auteur_id) FROM reponses_forum rf2 JOIN sujets_forum sf2 ON rf2.sujet_id = sf2.id WHERE sf2.forum_id = f.id) AS nb_participants
    FROM forums f WHERE f.statut = 'ouvert'
    ORDER BY nb_messages DESC
")->fetchAll();

// Visites 7 derniers jours
$visitsWeek = $pdo->query("
    SELECT DATE(date_visite) AS jour, COUNT(*) AS nb
    FROM statistiques_visites
    WHERE date_visite >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(date_visite)
    ORDER BY jour ASC
")->fetchAll();

// Publicités actives
$activeAds = $pdo->query("SELECT COUNT(*) FROM publicites WHERE statut = 'actif' AND date_fin >= CURDATE()")->fetchColumn();
$totalClics = $pdo->query("SELECT COALESCE(SUM(clics), 0) FROM publicites")->fetchColumn();
$totalImpressions = $pdo->query("SELECT COALESCE(SUM(impressions), 0) FROM publicites")->fetchColumn();

$currentAdmin = 'dashboard';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>

<div class="dashboard-layout">
    <!-- Sidebar -->
    <?php include __DIR__ . '/sidebar.php'; ?>

    <!-- Main -->
    <main class="dashboard-main">
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title">Tableau de bord</h1>
                <p class="text-muted">Vue d'ensemble de votre plateforme</p>
            </div>
            <div style="display:flex;gap:var(--spacing-sm);">
                <a href="<?= SITE_URL ?>/" class="btn btn-ghost btn-sm" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Voir le site
                </a>
                <a href="<?= SITE_URL ?>/admin/article_edit.php" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Nouvel article
                </a>
            </div>
        </div>

        <!-- Stat Cards -->
        <div class="grid grid-4" style="margin-bottom: var(--spacing-2xl);">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-icon" style="background:rgba(108,99,255,0.1);color:var(--accent-primary);">
                        <i class="fas fa-newspaper"></i>
                    </div>
                </div>
                <div class="stat-card-value"><?= $articlesPublies ?></div>
                <div class="stat-card-label">Articles publiés</div>
                <div class="stat-card-change up"><i class="fas fa-arrow-up"></i> <?= $totalArticles ?> total</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-icon" style="background:rgba(0,212,170,0.1);color:var(--success);">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="stat-card-value"><?= $totalUtilisateurs ?></div>
                <div class="stat-card-label">Utilisateurs</div>
                <div class="stat-card-change up"><i class="fas fa-arrow-up"></i> +<?= $newMembersMonth ?> ce mois</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-icon" style="background:rgba(168,85,247,0.1);color:var(--accent-secondary);">
                        <i class="fas fa-comments"></i>
                    </div>
                </div>
                <div class="stat-card-value"><?= number_format($totalForumMessages) ?></div>
                <div class="stat-card-label">Messages forum</div>
                <div class="stat-card-change"><?= $totalSujets ?> sujets</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-icon" style="background:rgba(255,184,77,0.1);color:var(--warning);">
                        <i class="fas fa-eye"></i>
                    </div>
                </div>
                <div class="stat-card-value"><?= number_format($totalVues) ?></div>
                <div class="stat-card-label">Vues totales</div>
                <div class="stat-card-change up"><i class="fas fa-arrow-up"></i> <?= $visitesToday ?> aujourd'hui</div>
            </div>
        </div>

        <div class="grid grid-2" style="margin-bottom: var(--spacing-2xl);">
            <!-- Graphique visites -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title"><i class="fas fa-chart-line text-accent"></i> Visites (7 jours)</h3>
                </div>
                <canvas id="visitsChart" height="200"></canvas>
            </div>

            <!-- Graphique articles par rubrique -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title"><i class="fas fa-chart-doughnut text-accent"></i> Articles par rubrique</h3>
                </div>
                <canvas id="rubriqueChart" height="200"></canvas>
            </div>
        </div>

        <!-- Statistiques Forum par thématique -->
        <div class="chart-container" style="margin-bottom: var(--spacing-2xl);">
            <div class="chart-header">
                <h3 class="chart-title"><i class="fas fa-chart-bar text-accent"></i> Participation aux forums</h3>
            </div>
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Forum / Thématique</th>
                            <th>Sujets</th>
                            <th>Messages</th>
                            <th>Participants</th>
                            <th>Engagement</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($forumStats as $fs): ?>
                        <tr>
                            <td><strong><?= sanitize($fs['titre']) ?></strong></td>
                            <td><?= number_format($fs['nb_sujets']) ?></td>
                            <td><?= number_format($fs['nb_messages']) ?></td>
                            <td><?= number_format($fs['nb_participants']) ?></td>
                            <td>
                                <?php $engagement = $fs['nb_sujets'] > 0 ? round($fs['nb_messages'] / $fs['nb_sujets'], 1) : 0; ?>
                                <div style="display:flex;align-items:center;gap:8px;">
                                    <div style="flex:1;height:6px;background:var(--bg-secondary);border-radius:3px;overflow:hidden;">
                                        <div style="height:100%;width:<?= min(100, $engagement * 10) ?>%;background:var(--accent-gradient);border-radius:3px;"></div>
                                    </div>
                                    <span style="font-size:0.8rem;color:var(--text-muted);"><?= $engagement ?> msg/sujet</span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="grid grid-2" style="margin-bottom: var(--spacing-2xl);">
            <!-- Top contributeurs -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title"><i class="fas fa-trophy text-warning"></i> Top contributeurs</h3>
                </div>
                <div>
                    <?php foreach ($topContributors as $idx => $tc): ?>
                    <div style="display:flex;align-items:center;gap:var(--spacing-md);padding:var(--spacing-sm) 0;<?= $idx < count($topContributors)-1 ? 'border-bottom:1px solid var(--border-color);' : '' ?>">
                        <span style="font-weight:800;color:var(--text-muted);width:24px;text-align:center;"><?= $idx + 1 ?></span>
                        <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($tc['avatar']) ?>" alt=""
                             onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'"
                             style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
                        <div style="flex:1;">
                            <div style="font-weight:600;font-size:0.9rem;"><?= sanitize($tc['prenom'] . ' ' . $tc['nom']) ?></div>
                            <div style="font-size:0.75rem;color:var(--text-muted);">
                                <?= $tc['nb_reponses'] ?> réponses &middot; <?= $tc['nb_sujets'] ?> sujets &middot; <?= $tc['nb_commentaires'] ?> commentaires
                            </div>
                        </div>
                        <span class="tag tag-primary"><?= $tc['nb_reponses'] + $tc['nb_sujets'] + $tc['nb_commentaires'] ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Derniers articles -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title"><i class="fas fa-clock text-accent"></i> Derniers articles</h3>
                    <a href="<?= SITE_URL ?>/admin/articles.php" class="btn btn-ghost btn-sm">Voir tout</a>
                </div>
                <div>
                    <?php foreach ($recentArticles as $ra): ?>
                    <div style="display:flex;align-items:center;gap:var(--spacing-md);padding:var(--spacing-sm) 0;border-bottom:1px solid var(--border-color);">
                        <div style="flex:1;min-width:0;">
                            <div style="font-weight:600;font-size:0.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                <?= sanitize($ra['titre']) ?>
                            </div>
                            <div style="font-size:0.75rem;color:var(--text-muted);">
                                <?= sanitize($ra['prenom'] . ' ' . $ra['auteur_nom']) ?> &middot; <?= formatDate($ra['date_creation'], 'relative') ?>
                            </div>
                        </div>
                        <span class="tag tag-<?= $ra['statut'] === 'publie' ? 'success' : ($ra['statut'] === 'brouillon' ? 'warning' : 'primary') ?>">
                            <?= ucfirst($ra['statut']) ?>
                        </span>
                        <a href="<?= SITE_URL ?>/admin/article_edit.php?id=<?= $ra['id'] ?>" class="btn btn-ghost btn-sm">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Publicités -->
        <div class="grid grid-3" style="margin-bottom: var(--spacing-2xl);">
            <div class="stat-card">
                <div class="stat-card-icon" style="background:rgba(78,205,196,0.1);color:var(--info);">
                    <i class="fas fa-ad"></i>
                </div>
                <div class="stat-card-value"><?= $activeAds ?></div>
                <div class="stat-card-label">Publicités actives</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon" style="background:rgba(108,99,255,0.1);color:var(--accent-primary);">
                    <i class="fas fa-mouse-pointer"></i>
                </div>
                <div class="stat-card-value"><?= number_format($totalClics) ?></div>
                <div class="stat-card-label">Clics publicitaires</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon" style="background:rgba(255,184,77,0.1);color:var(--warning);">
                    <i class="fas fa-bullhorn"></i>
                </div>
                <div class="stat-card-value"><?= number_format($totalImpressions) ?></div>
                <div class="stat-card-label">Impressions</div>
            </div>
        </div>

    </main>
</div>

<script>
// Graphique visites
const visitsCtx = document.getElementById('visitsChart').getContext('2d');
new Chart(visitsCtx, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($v) { return '"' . date('d/m', strtotime($v['jour'])) . '"'; }, $visitsWeek)) ?>],
        datasets: [{
            label: 'Visites',
            data: [<?= implode(',', array_column($visitsWeek, 'nb')) ?>],
            borderColor: '#6C63FF',
            backgroundColor: 'rgba(108,99,255,0.1)',
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#6C63FF',
            pointBorderWidth: 0,
            pointRadius: 4
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { color: 'rgba(108,99,255,0.05)' }, ticks: { color: '#6B6B80' } },
            y: { grid: { color: 'rgba(108,99,255,0.05)' }, ticks: { color: '#6B6B80' }, beginAtZero: true }
        }
    }
});

// Graphique rubriques
const rubCtx = document.getElementById('rubriqueChart').getContext('2d');
new Chart(rubCtx, {
    type: 'doughnut',
    data: {
        labels: [<?= implode(',', array_map(function($r) { return '"' . $r['nom'] . '"'; }, $articlesByRubrique)) ?>],
        datasets: [{
            data: [<?= implode(',', array_column($articlesByRubrique, 'nb')) ?>],
            backgroundColor: [<?= implode(',', array_map(function($r) { return '"' . $r['couleur'] . '"'; }, $articlesByRubrique)) ?>],
            borderWidth: 0,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true,
        cutout: '65%',
        plugins: {
            legend: { position: 'bottom', labels: { color: '#A0A0B8', padding: 15, usePointStyle: true } }
        }
    }
});
</script>

</body>
</html>
