<?php
/**
 * Admin sidebar navigation (included in all admin pages)
 */
?>
<aside class="dashboard-sidebar">
    <a href="<?= SITE_URL ?>/" class="logo">
        <span class="logo-icon">AE</span>
        ACTU Events
    </a>

    <div class="sidebar-section-title">Principal</div>
    <ul class="sidebar-menu">
        <li><a href="<?= SITE_URL ?>/admin/" class="<?= ($currentAdmin ?? '') === 'dashboard' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i> Tableau de bord
        </a></li>
        <li><a href="<?= SITE_URL ?>/admin/statistiques.php" class="<?= ($currentAdmin ?? '') === 'statistiques' ? 'active' : '' ?>">
            <i class="fas fa-chart-bar"></i> Statistiques
        </a></li>
    </ul>

    <div class="sidebar-section-title">Contenu</div>
    <ul class="sidebar-menu">
        <li><a href="<?= SITE_URL ?>/admin/articles.php" class="<?= ($currentAdmin ?? '') === 'articles' ? 'active' : '' ?>">
            <i class="fas fa-newspaper"></i> Articles
        </a></li>
        <li><a href="<?= SITE_URL ?>/admin/article_edit.php" class="<?= ($currentAdmin ?? '') === 'article_edit' ? 'active' : '' ?>">
            <i class="fas fa-plus-circle"></i> Nouvel article
        </a></li>
        <li><a href="<?= SITE_URL ?>/admin/rubriques.php" class="<?= ($currentAdmin ?? '') === 'rubriques' ? 'active' : '' ?>">
            <i class="fas fa-tags"></i> Rubriques
        </a></li>
        <li><a href="<?= SITE_URL ?>/admin/forums_admin.php" class="<?= ($currentAdmin ?? '') === 'forums' ? 'active' : '' ?>">
            <i class="fas fa-comments"></i> Forums
        </a></li>
    </ul>

    <div class="sidebar-section-title">Partenaires</div>
    <ul class="sidebar-menu">
        <li><a href="<?= SITE_URL ?>/admin/publicites.php" class="<?= ($currentAdmin ?? '') === 'publicites' ? 'active' : '' ?>">
            <i class="fas fa-ad"></i> Publicités
        </a></li>
    </ul>

    <div class="sidebar-section-title">Utilisateurs</div>
    <ul class="sidebar-menu">
        <li><a href="<?= SITE_URL ?>/admin/utilisateurs.php" class="<?= ($currentAdmin ?? '') === 'utilisateurs' ? 'active' : '' ?>">
            <i class="fas fa-users"></i> Utilisateurs
        </a></li>
    </ul>

    <div style="position:absolute;bottom:var(--spacing-lg);left:var(--spacing-lg);right:var(--spacing-lg);">
        <div style="display:flex;align-items:center;gap:var(--spacing-sm);padding:var(--spacing-md);background:var(--bg-card);border-radius:var(--radius-md);border:1px solid var(--border-color);">
            <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($_SESSION['user_avatar'] ?? 'default-avatar.svg') ?>" alt=""
                 onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'"
                 style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
            <div style="flex:1;min-width:0;">
                <div style="font-weight:600;font-size:0.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                    <?= sanitize($_SESSION['user_prenom'] ?? '') ?>
                </div>
                <div style="font-size:0.7rem;color:var(--text-muted);"><?= ucfirst($_SESSION['user_role'] ?? '') ?></div>
            </div>
            <a href="<?= SITE_URL ?>/deconnexion.php" title="Déconnexion" style="color:var(--text-muted);">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
</aside>
