<?php
/**
 * Admin - Créer / Modifier un article
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin() && !isEditor()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'article_edit';
$pageTitle = 'Éditeur d\'article';

$articleId = intval($_GET['id'] ?? 0);
$article = null;

if ($articleId) {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$articleId]);
    $article = $stmt->fetch();
    if (!$article) { setFlash('error', 'Article introuvable.'); redirect(SITE_URL . '/admin/articles.php'); }
    $currentAdmin = 'articles';
}

$rubriques = $pdo->query("SELECT id, nom FROM rubriques WHERE statut = 'actif' ORDER BY nom")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Token invalide.');
        redirect($_SERVER['REQUEST_URI']);
    }

    $titre = trim($_POST['titre'] ?? '');
    $contenu = $_POST['contenu'] ?? '';
    $extrait = trim($_POST['extrait'] ?? '');
    $rubrique_id = intval($_POST['rubrique_id'] ?? 0);
    $statut = $_POST['statut'] ?? 'brouillon';
    $mise_en_avant = isset($_POST['mise_en_avant']) ? 1 : 0;
    $date_evenement = $_POST['date_evenement'] ?? null;
    $lieu_evenement = trim($_POST['lieu_evenement'] ?? '');

    $errors = [];
    if (empty($titre)) $errors[] = 'Le titre est obligatoire.';
    if (empty($contenu)) $errors[] = 'Le contenu est obligatoire.';
    if (!$rubrique_id) $errors[] = 'Veuillez choisir une rubrique.';

    // Image
    $image = $article['image_principale'] ?? null;
    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($_FILES['image'], 'articles');
        if ($result['success']) {
            $image = $result['filename'];
        } else {
            $errors[] = $result['error'];
        }
    }

    if (empty($errors)) {
        $slug = generateSlug($titre);

        if ($article) {
            // Mise à jour
            $datePubli = ($statut === 'publie' && $article['statut'] !== 'publie') ? date('Y-m-d H:i:s') : $article['date_publication'];
            $stmt = $pdo->prepare("UPDATE articles SET titre=?, slug=?, contenu=?, extrait=?, image_principale=?, rubrique_id=?, statut=?, mise_en_avant=?, date_evenement=?, lieu_evenement=?, date_publication=? WHERE id=?");
            $stmt->execute([$titre, $slug, $contenu, $extrait, $image, $rubrique_id, $statut, $mise_en_avant, $date_evenement ?: null, $lieu_evenement, $datePubli, $article['id']]);
            setFlash('success', 'Article mis à jour !');
        } else {
            // Création
            $datePubli = $statut === 'publie' ? date('Y-m-d H:i:s') : null;
            $slug .= '-' . uniqid();
            $stmt = $pdo->prepare("INSERT INTO articles (titre, slug, contenu, extrait, image_principale, rubrique_id, auteur_id, statut, mise_en_avant, date_evenement, lieu_evenement, date_publication) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$titre, $slug, $contenu, $extrait, $image, $rubrique_id, $_SESSION['user_id'], $statut, $mise_en_avant, $date_evenement ?: null, $lieu_evenement, $datePubli]);
            setFlash('success', 'Article créé !');
        }
        redirect(SITE_URL . '/admin/articles.php');
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $article ? 'Modifier' : 'Nouvel' ?> article | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><?= $article ? 'Modifier l\'article' : 'Nouvel article' ?></h1>
            <a href="<?= SITE_URL ?>/admin/articles.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Retour</a>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i>
            <div><?php foreach ($errors as $e) echo '<p>' . sanitize($e) . '</p>'; ?></div>
        </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
            
            <div class="grid" style="grid-template-columns: 1fr 340px; gap: var(--spacing-xl);">
                <!-- Colonne principale -->
                <div>
                    <div class="card" style="padding:var(--spacing-xl);margin-bottom:var(--spacing-lg);">
                        <div class="form-group">
                            <label class="form-label">Titre de l'article *</label>
                            <input type="text" name="titre" class="form-control" placeholder="Titre de l'article"
                                   value="<?= sanitize($article['titre'] ?? $titre ?? '') ?>" required
                                   style="font-size:1.2rem;font-weight:600;">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Extrait / Chapô</label>
                            <textarea name="extrait" class="form-control" rows="3" 
                                      placeholder="Résumé court de l'article..."><?= sanitize($article['extrait'] ?? $extrait ?? '') ?></textarea>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Contenu *</label>
                            <textarea name="contenu" id="contenu" class="form-control" rows="15"
                                      placeholder="Rédigez le contenu de votre article... Vous pouvez utiliser du HTML."
                                      style="min-height:400px;font-family:monospace;font-size:0.9rem;"
                                      required><?= $article['contenu'] ?? $contenu ?? '' ?></textarea>
                            <small class="text-muted">Vous pouvez utiliser du HTML pour la mise en forme (h2, p, img, blockquote, etc.)</small>
                        </div>
                    </div>
                </div>

                <!-- Sidebar droite -->
                <div>
                    <!-- Publication -->
                    <div class="card" style="padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);">
                        <h3 style="font-weight:700;margin-bottom:var(--spacing-md);font-size:0.95rem;">Publication</h3>
                        
                        <div class="form-group">
                            <label class="form-label">Statut</label>
                            <select name="statut" class="form-control">
                                <option value="brouillon" <?= ($article['statut'] ?? '') === 'brouillon' ? 'selected' : '' ?>>Brouillon</option>
                                <option value="publie" <?= ($article['statut'] ?? '') === 'publie' ? 'selected' : '' ?>>Publié</option>
                                <option value="archive" <?= ($article['statut'] ?? '') === 'archive' ? 'selected' : '' ?>>Archivé</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Rubrique *</label>
                            <select name="rubrique_id" class="form-control" required>
                                <option value="">-- Choisir --</option>
                                <?php foreach ($rubriques as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= ($article['rubrique_id'] ?? $rubrique_id ?? 0) == $r['id'] ? 'selected' : '' ?>>
                                    <?= sanitize($r['nom']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-check">
                                <input type="checkbox" name="mise_en_avant" value="1" <?= ($article['mise_en_avant'] ?? 0) ? 'checked' : '' ?>>
                                <span style="font-size:0.85rem;">Mettre en avant (hero)</span>
                            </label>
                        </div>

                        <div style="display:flex;gap:var(--spacing-sm);">
                            <button type="submit" class="btn btn-primary" style="flex:1;">
                                <i class="fas fa-save"></i> <?= $article ? 'Mettre à jour' : 'Publier' ?>
                            </button>
                        </div>
                    </div>

                    <!-- Image -->
                    <div class="card" style="padding:var(--spacing-lg);margin-bottom:var(--spacing-lg);">
                        <h3 style="font-weight:700;margin-bottom:var(--spacing-md);font-size:0.95rem;">Image principale</h3>
                        
                        <?php if ($article && $article['image_principale']): ?>
                        <img src="<?= UPLOAD_URL ?>articles/<?= sanitize($article['image_principale']) ?>" alt="" 
                             id="imagePreview"
                             style="width:100%;border-radius:var(--radius-md);margin-bottom:var(--spacing-md);max-height:200px;object-fit:cover;">
                        <?php else: ?>
                        <img id="imagePreview" alt="" style="display:none;width:100%;border-radius:var(--radius-md);margin-bottom:var(--spacing-md);max-height:200px;object-fit:cover;">
                        <?php endif; ?>
                        
                        <label class="btn btn-secondary btn-sm w-100" style="cursor:pointer;">
                            <i class="fas fa-image"></i> Choisir une image
                            <input type="file" name="image" accept="image/*" style="display:none;" 
                                   onchange="const p=document.getElementById('imagePreview');p.src=URL.createObjectURL(this.files[0]);p.style.display='block';">
                        </label>
                    </div>

                    <!-- Événement -->
                    <div class="card" style="padding:var(--spacing-lg);">
                        <h3 style="font-weight:700;margin-bottom:var(--spacing-md);font-size:0.95rem;">
                            <i class="fas fa-calendar-alt text-accent"></i> Événement
                        </h3>
                        <div class="form-group">
                            <label class="form-label">Date de l'événement</label>
                            <input type="date" name="date_evenement" class="form-control"
                                   value="<?= $article['date_evenement'] ?? $date_evenement ?? '' ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Lieu</label>
                            <input type="text" name="lieu_evenement" class="form-control" placeholder="Lieu de l'événement"
                                   value="<?= sanitize($article['lieu_evenement'] ?? $lieu_evenement ?? '') ?>">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </main>
</div>
</body>
</html>
