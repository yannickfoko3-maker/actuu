<?php
/**
 * Admin - Gestion des rubriques/catégories
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'rubriques';
$pageTitle = 'Rubriques';

// Suppression
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $check = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE rubrique_id = ?");
    $check->execute([$id]);
    if ($check->fetchColumn() > 0) {
        setFlash('error', 'Impossible de supprimer : des articles sont liés à cette rubrique.');
    } else {
        $pdo->prepare("DELETE FROM rubriques WHERE id = ?")->execute([$id]);
        setFlash('success', 'Rubrique supprimée.');
    }
    redirect(SITE_URL . '/admin/rubriques.php');
}

// Ajout / Modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) { setFlash('error', 'Token invalide.'); redirect($_SERVER['REQUEST_URI']); }

    $id = intval($_POST['id'] ?? 0);
    $nom = trim($_POST['nom'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $couleur = $_POST['couleur'] ?? '#6C63FF';
    $icone = $_POST['icone'] ?? 'fa-folder';
    $ordre = intval($_POST['ordre'] ?? 0);
    $statut = $_POST['statut'] ?? 'actif';

    if (empty($nom)) {
        setFlash('error', 'Le nom est obligatoire.');
    } else {
        $slug = generateSlug($nom);
        if ($id) {
            $pdo->prepare("UPDATE rubriques SET nom=?,slug=?,description=?,couleur=?,icone=?,ordre=?,statut=? WHERE id=?")
                ->execute([$nom, $slug, $description, $couleur, $icone, $ordre, $statut, $id]);
            setFlash('success', 'Rubrique mise à jour !');
        } else {
            $pdo->prepare("INSERT INTO rubriques (nom,slug,description,couleur,icone,ordre,statut) VALUES (?,?,?,?,?,?,?)")
                ->execute([$nom, $slug, $description, $couleur, $icone, $ordre, $statut]);
            setFlash('success', 'Rubrique créée !');
        }
    }
    redirect(SITE_URL . '/admin/rubriques.php');
}

$editRub = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM rubriques WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editRub = $stmt->fetch();
}

$rubriques = $pdo->query("
    SELECT r.*, (SELECT COUNT(*) FROM articles WHERE rubrique_id = r.id) AS nb_articles
    FROM rubriques r ORDER BY r.ordre ASC
")->fetchAll();

$icones = ['fa-rocket','fa-microchip','fa-palette','fa-graduation-cap','fa-handshake','fa-microphone','fa-globe','fa-lightbulb','fa-heart','fa-briefcase','fa-building','fa-calendar','fa-camera','fa-chart-line','fa-code','fa-cogs','fa-music','fa-star','fa-trophy','fa-users','fa-flag','fa-book'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rubriques | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><i class="fas fa-tags text-accent"></i> Rubriques</h1>
        </div>

        <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
        <?php endif; ?>

        <div class="grid" style="grid-template-columns: 1fr 380px; gap: var(--spacing-xl);">
            <!-- Liste -->
            <div class="chart-container" style="padding:0;overflow:hidden;">
                <table class="data-table">
                    <thead><tr><th>Rubrique</th><th>Slug</th><th>Articles</th><th>Ordre</th><th>Statut</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($rubriques as $rub): ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:8px;">
                                    <span style="width:36px;height:36px;border-radius:8px;background:<?= $rub['couleur'] ?>15;color:<?= $rub['couleur'] ?>;display:flex;align-items:center;justify-content:center;">
                                        <i class="fas <?= $rub['icone'] ?>"></i>
                                    </span>
                                    <strong><?= sanitize($rub['nom']) ?></strong>
                                </div>
                            </td>
                            <td style="font-size:0.8rem;color:var(--text-muted);font-family:monospace;"><?= $rub['slug'] ?></td>
                            <td><span class="tag tag-primary"><?= $rub['nb_articles'] ?></span></td>
                            <td><?= $rub['ordre'] ?></td>
                            <td><span class="tag tag-<?= $rub['statut']==='actif'?'success':'warning' ?>"><?= ucfirst($rub['statut']) ?></span></td>
                            <td>
                                <a href="?edit=<?= $rub['id'] ?>" class="btn btn-ghost btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $rub['id'] ?>" class="btn btn-ghost btn-sm" style="color:var(--danger);" onclick="return confirm('Supprimer cette rubrique ?');"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Formulaire -->
            <div class="card" style="padding:var(--spacing-lg);">
                <h3 style="font-weight:700;margin-bottom:var(--spacing-lg);font-size:0.95rem;">
                    <?= $editRub ? 'Modifier la rubrique' : 'Nouvelle rubrique' ?>
                </h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="id" value="<?= $editRub['id'] ?? 0 ?>">

                    <div class="form-group">
                        <label class="form-label">Nom *</label>
                        <input type="text" name="nom" class="form-control" value="<?= sanitize($editRub['nom'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3"><?= sanitize($editRub['description'] ?? '') ?></textarea>
                    </div>
                    <div class="grid grid-2">
                        <div class="form-group">
                            <label class="form-label">Couleur</label>
                            <input type="color" name="couleur" class="form-control" value="<?= $editRub['couleur'] ?? '#6C63FF' ?>" style="height:44px;padding:4px;">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ordre</label>
                            <input type="number" name="ordre" class="form-control" value="<?= $editRub['ordre'] ?? 0 ?>" min="0">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Icône</label>
                        <select name="icone" class="form-control">
                            <?php foreach ($icones as $ico): ?>
                            <option value="<?= $ico ?>" <?= ($editRub['icone'] ?? 'fa-folder') === $ico ? 'selected' : '' ?>>
                                <?= $ico ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:8px;">
                            <?php foreach ($icones as $ico): ?>
                            <span style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;background:var(--bg-secondary);border-radius:4px;cursor:pointer;font-size:0.85rem;color:var(--text-secondary);" 
                                  title="<?= $ico ?>" onclick="this.closest('form').querySelector('[name=icone]').value='<?= $ico ?>';">
                                <i class="fas <?= $ico ?>"></i>
                            </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Statut</label>
                        <select name="statut" class="form-control">
                            <option value="actif" <?= ($editRub['statut'] ?? 'actif') === 'actif' ? 'selected' : '' ?>>Actif</option>
                            <option value="inactif" <?= ($editRub['statut'] ?? '') === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save"></i> <?= $editRub ? 'Mettre à jour' : 'Créer' ?>
                    </button>
                    <?php if ($editRub): ?>
                    <a href="<?= SITE_URL ?>/admin/rubriques.php" class="btn btn-secondary w-100 mt-1">Annuler</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
