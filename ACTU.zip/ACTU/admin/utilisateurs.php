<?php
/**
 * Admin - Gestion des utilisateurs
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'utilisateurs';
$pageTitle = 'Utilisateurs';

// Changer statut
if (isset($_GET['toggle'])) {
    $uid = intval($_GET['toggle']);
    if ($uid !== $_SESSION['user_id']) {
        $user = $pdo->prepare("SELECT statut FROM utilisateurs WHERE id = ?");
        $user->execute([$uid]);
        $current = $user->fetchColumn();
        $newStatus = $current === 'actif' ? 'inactif' : 'actif';
        $pdo->prepare("UPDATE utilisateurs SET statut = ? WHERE id = ?")->execute([$newStatus, $uid]);
        setFlash('success', 'Statut utilisateur modifié.');
    }
    redirect(SITE_URL . '/admin/utilisateurs.php');
}

// Changer rôle
if (isset($_GET['role']) && isset($_GET['uid'])) {
    $uid = intval($_GET['uid']);
    $role = $_GET['role'];
    if ($uid !== $_SESSION['user_id'] && in_array($role, ['admin','editeur','moderateur','utilisateur'])) {
        $pdo->prepare("UPDATE utilisateurs SET role = ? WHERE id = ?")->execute([$role, $uid]);
        setFlash('success', 'Rôle modifié.');
    }
    redirect(SITE_URL . '/admin/utilisateurs.php');
}

// Suppression
if (isset($_GET['delete'])) {
    $uid = intval($_GET['delete']);
    if ($uid !== $_SESSION['user_id']) {
        $pdo->prepare("DELETE FROM utilisateurs WHERE id = ?")->execute([$uid]);
        setFlash('success', 'Utilisateur supprimé.');
    }
    redirect(SITE_URL . '/admin/utilisateurs.php');
}

$search = trim($_GET['search'] ?? '');
$filterRole = $_GET['role_filter'] ?? '';

$where = "1=1";
$params = [];
if (!empty($search)) {
    $where .= " AND (u.nom LIKE ? OR u.prenom LIKE ? OR u.email LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}
if (!empty($filterRole)) {
    $where .= " AND u.role = ?";
    $params[] = $filterRole;
}

$utilisateurs = $pdo->prepare("
    SELECT u.*,
           (SELECT COUNT(*) FROM commentaires WHERE auteur_id = u.id) AS nb_commentaires,
           (SELECT COUNT(*) FROM reponses_forum WHERE auteur_id = u.id) AS nb_reponses_forum,
           (SELECT COUNT(*) FROM sujets_forum WHERE auteur_id = u.id) AS nb_sujets
    FROM utilisateurs u
    WHERE $where
    ORDER BY u.date_inscription DESC
");
$utilisateurs->execute($params);
$users = $utilisateurs->fetchAll();

$totalByRole = $pdo->query("SELECT role, COUNT(*) as nb FROM utilisateurs GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Utilisateurs | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><i class="fas fa-users text-accent"></i> Utilisateurs</h1>
        </div>

        <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
        <?php endif; ?>

        <!-- Stats rapides -->
        <div class="grid grid-4" style="margin-bottom:var(--spacing-xl);">
            <div class="stat-card">
                <div class="stat-card-value" style="font-size:1.5rem;"><?= array_sum($totalByRole) ?></div>
                <div class="stat-card-label">Total</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-value" style="font-size:1.5rem;"><?= $totalByRole['admin'] ?? 0 ?></div>
                <div class="stat-card-label">Admins</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-value" style="font-size:1.5rem;"><?= $totalByRole['editeur'] ?? 0 ?></div>
                <div class="stat-card-label">Éditeurs</div>
            </div>
            <div class="stat-card">
                <div class="stat-card-value" style="font-size:1.5rem;"><?= $totalByRole['utilisateur'] ?? 0 ?></div>
                <div class="stat-card-label">Utilisateurs</div>
            </div>
        </div>

        <!-- Filtres -->
        <div style="display:flex;gap:var(--spacing-md);margin-bottom:var(--spacing-xl);flex-wrap:wrap;align-items:center;">
            <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px;">
                <input type="text" name="search" class="form-control" placeholder="Rechercher..." value="<?= sanitize($search) ?>" style="max-width:300px;">
                <select name="role_filter" class="form-control" style="max-width:180px;" onchange="this.form.submit()">
                    <option value="">Tous les rôles</option>
                    <option value="admin" <?= $filterRole==='admin'?'selected':'' ?>>Admin</option>
                    <option value="editeur" <?= $filterRole==='editeur'?'selected':'' ?>>Éditeur</option>
                    <option value="moderateur" <?= $filterRole==='moderateur'?'selected':'' ?>>Modérateur</option>
                    <option value="utilisateur" <?= $filterRole==='utilisateur'?'selected':'' ?>>Utilisateur</option>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm"><i class="fas fa-search"></i></button>
            </form>
        </div>

        <!-- Table -->
        <div class="chart-container" style="padding:0;overflow:hidden;">
            <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead><tr><th>Utilisateur</th><th>Email</th><th>Rôle</th><th>Activité</th><th>Inscription</th><th>Statut</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:8px;">
                                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($u['avatar']) ?>" alt=""
                                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'"
                                         style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
                                    <div>
                                        <div style="font-weight:600;font-size:0.9rem;"><?= sanitize($u['prenom'] . ' ' . $u['nom']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td style="font-size:0.85rem;"><?= sanitize($u['email']) ?></td>
                            <td>
                                <select onchange="window.location='?uid=<?= $u['id'] ?>&role='+this.value" class="form-control" style="padding:4px 8px;font-size:0.8rem;width:auto;" <?= $u['id'] == $_SESSION['user_id'] ? 'disabled' : '' ?>>
                                    <?php foreach (['admin','editeur','moderateur','utilisateur'] as $r): ?>
                                    <option value="<?= $r ?>" <?= $u['role']===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td style="font-size:0.8rem;">
                                <span title="Commentaires"><i class="fas fa-comment"></i> <?= $u['nb_commentaires'] ?></span>&nbsp;
                                <span title="Sujets"><i class="fas fa-file-alt"></i> <?= $u['nb_sujets'] ?></span>&nbsp;
                                <span title="Réponses forum"><i class="fas fa-reply"></i> <?= $u['nb_reponses_forum'] ?></span>
                            </td>
                            <td style="font-size:0.8rem;color:var(--text-muted);"><?= formatDate($u['date_inscription'], 'short') ?></td>
                            <td><span class="tag tag-<?= $u['statut']==='actif'?'success':($u['statut']==='banni'?'danger':'warning') ?>"><?= ucfirst($u['statut']) ?></span></td>
                            <td>
                                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                <a href="?toggle=<?= $u['id'] ?>" class="btn btn-ghost btn-sm" title="<?= $u['statut']==='actif'?'Désactiver':'Activer' ?>">
                                    <i class="fas fa-<?= $u['statut']==='actif'?'ban':'check' ?>"></i>
                                </a>
                                <a href="?delete=<?= $u['id'] ?>" class="btn btn-ghost btn-sm" style="color:var(--danger);" onclick="return confirm('Supprimer cet utilisateur ?');">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
