<?php
/**
 * Admin - Gestion des articles (CRUD)
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin() && !isEditor()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'articles';
$pageTitle = 'Gestion des articles';

// Suppression
if (isset($_GET['delete']) && isAdmin()) {
    $pdo->prepare("DELETE FROM articles WHERE id = ?")->execute([intval($_GET['delete'])]);
    setFlash('success', 'Article supprimé.');
    redirect(SITE_URL . '/admin/articles.php');
}

// Filtres
$filter = $_GET['filter'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$rubFilter = intval($_GET['rubrique'] ?? 0);

$where = "1=1";
$params = [];

if ($filter === 'publie') { $where .= " AND a.statut = 'publie'"; }
elseif ($filter === 'brouillon') { $where .= " AND a.statut = 'brouillon'"; }
elseif ($filter === 'archive') { $where .= " AND a.statut = 'archive'"; }

if (!empty($search)) {
    $where .= " AND (a.titre LIKE ? OR a.contenu LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($rubFilter) {
    $where .= " AND a.rubrique_id = ?";
    $params[] = $rubFilter;
}

$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * 20;

$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM articles a WHERE $where");
$stmtCount->execute($params);
$total = $stmtCount->fetchColumn();
$totalPages = ceil($total / 20);

$stmtArticles = $pdo->prepare("
    SELECT a.*, r.nom AS rubrique_nom, r.couleur, u.prenom, u.nom AS auteur_nom
    FROM articles a
    JOIN rubriques r ON a.rubrique_id = r.id
    JOIN utilisateurs u ON a.auteur_id = u.id
    WHERE $where
    ORDER BY a.date_creation DESC
    LIMIT 20 OFFSET $offset
");
$stmtArticles->execute($params);
$articles = $stmtArticles->fetchAll();

$rubriques = $pdo->query("SELECT id, nom FROM rubriques WHERE statut = 'actif' ORDER BY nom")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Articles | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title">Articles</h1>
            <a href="<?= SITE_URL ?>/admin/article_edit.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nouvel article
            </a>
        </div>

        <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
        <?php endif; ?>

        <!-- Filtres -->
        <div style="display:flex;gap:var(--spacing-md);margin-bottom:var(--spacing-xl);flex-wrap:wrap;align-items:center;">
            <div style="display:flex;gap:4px;">
                <a href="?filter=all" class="btn <?= $filter==='all' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Tous (<?= $total ?>)</a>
                <a href="?filter=publie" class="btn <?= $filter==='publie' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Publiés</a>
                <a href="?filter=brouillon" class="btn <?= $filter==='brouillon' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Brouillons</a>
                <a href="?filter=archive" class="btn <?= $filter==='archive' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Archivés</a>
            </div>
            <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px;">
                <input type="hidden" name="filter" value="<?= $filter ?>">
                <input type="text" name="search" class="form-control" placeholder="Rechercher un article..." 
                       value="<?= sanitize($search) ?>" style="max-width:300px;">
                <select name="rubrique" class="form-control" style="max-width:200px;" onchange="this.form.submit()">
                    <option value="0">Toutes rubriques</option>
                    <?php foreach ($rubriques as $r): ?>
                    <option value="<?= $r['id'] ?>" <?= $rubFilter == $r['id'] ? 'selected' : '' ?>><?= sanitize($r['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm"><i class="fas fa-search"></i></button>
            </form>
        </div>

        <!-- Table -->
        <div class="chart-container" style="padding:0;overflow:hidden;">
            <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Rubrique</th>
                            <th>Auteur</th>
                            <th>Statut</th>
                            <th>Vues</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($articles)): ?>
                        <tr><td colspan="7" style="text-align:center;padding:var(--spacing-2xl);color:var(--text-muted);">Aucun article trouvé.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($articles as $art): ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center;gap:var(--spacing-sm);">
                                    <?php if ($art['image_principale']): ?>
                                    <img src="<?= UPLOAD_URL ?>articles/<?= sanitize($art['image_principale']) ?>" alt=""
                                         style="width:40px;height:40px;border-radius:var(--radius-sm);object-fit:cover;">
                                    <?php endif; ?>
                                    <div style="max-width:250px;">
                                        <div style="font-weight:600;font-size:0.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                            <?= sanitize($art['titre']) ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><span class="tag" style="background:<?= $art['couleur'] ?>20;color:<?= $art['couleur'] ?>;"><?= sanitize($art['rubrique_nom']) ?></span></td>
                            <td style="font-size:0.85rem;"><?= sanitize($art['prenom'] . ' ' . $art['auteur_nom']) ?></td>
                            <td><span class="tag tag-<?= $art['statut']==='publie'?'success':($art['statut']==='brouillon'?'warning':'primary') ?>"><?= ucfirst($art['statut']) ?></span></td>
                            <td><?= number_format($art['vues']) ?></td>
                            <td style="font-size:0.8rem;color:var(--text-muted);"><?= formatDate($art['date_creation'], 'short') ?></td>
                            <td>
                                <div style="display:flex;gap:4px;">
                                    <a href="<?= SITE_URL ?>/article.php?slug=<?= $art['slug'] ?>" class="btn btn-ghost btn-sm" target="_blank" title="Voir"><i class="fas fa-eye"></i></a>
                                    <a href="<?= SITE_URL ?>/admin/article_edit.php?id=<?= $art['id'] ?>" class="btn btn-ghost btn-sm" title="Modifier"><i class="fas fa-edit"></i></a>
                                    <a href="?delete=<?= $art['id'] ?>" class="btn btn-ghost btn-sm" title="Supprimer" onclick="return confirm('Supprimer cet article ?');" style="color:var(--danger);"><i class="fas fa-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($totalPages > 1): ?>
        <nav class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?><span class="active"><?= $i ?></span>
                <?php else: ?><a href="?filter=<?= $filter ?>&search=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a><?php endif; ?>
            <?php endfor; ?>
        </nav>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
