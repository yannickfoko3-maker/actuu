<?php
/**
 * Admin - Statistiques détaillées
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin() && !isEditor()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'statistiques';
$pageTitle = 'Statistiques';

// Période
$periode = $_GET['periode'] ?? '30';

// Visites par jour
$visitsDaily = $pdo->prepare("
    SELECT DATE(date_visite) AS jour, COUNT(*) AS nb
    FROM statistiques_visites
    WHERE date_visite >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
    GROUP BY DATE(date_visite) ORDER BY jour ASC
");
$visitsDaily->execute([$periode]);
$visitsData = $visitsDaily->fetchAll();

// Pages les plus vues
$topPages = $pdo->query("
    SELECT page, COUNT(*) AS nb FROM statistiques_visites
    GROUP BY page ORDER BY nb DESC LIMIT 10
")->fetchAll();

// Articles les plus vus
$topArticles = $pdo->query("
    SELECT a.titre, a.slug, a.vues, r.nom AS rubrique_nom, r.couleur
    FROM articles a JOIN rubriques r ON a.rubrique_id = r.id
    WHERE a.statut = 'publie' ORDER BY a.vues DESC LIMIT 10
")->fetchAll();

// Participation forum par utilisateur (top 15)
$forumParticipation = $pdo->query("
    SELECT u.prenom, u.nom, u.avatar,
           (SELECT COUNT(*) FROM sujets_forum WHERE auteur_id = u.id) AS sujets,
           (SELECT COUNT(*) FROM reponses_forum WHERE auteur_id = u.id) AS reponses,
           (SELECT COUNT(*) FROM commentaires WHERE auteur_id = u.id) AS commentaires
    FROM utilisateurs u WHERE u.statut = 'actif'
    HAVING (sujets + reponses + commentaires) > 0
    ORDER BY (sujets + reponses + commentaires) DESC LIMIT 15
")->fetchAll();

// Activité par thématique
$activityByTheme = $pdo->query("
    SELECT r.nom, r.couleur,
           (SELECT COUNT(*) FROM articles a WHERE a.rubrique_id = r.id AND a.statut = 'publie') AS articles,
           (SELECT COUNT(*) FROM forums f WHERE f.rubrique_id = r.id) AS forums,
           (SELECT COUNT(*) FROM sujets_forum sf JOIN forums f2 ON sf.forum_id = f2.id WHERE f2.rubrique_id = r.id) AS sujets,
           (SELECT COUNT(*) FROM reponses_forum rf JOIN sujets_forum sf2 ON rf.sujet_id = sf2.id JOIN forums f3 ON sf2.forum_id = f3.id WHERE f3.rubrique_id = r.id) AS messages
    FROM rubriques r WHERE r.statut = 'actif' ORDER BY r.ordre ASC
")->fetchAll();

// Inscriptions par mois (6 derniers mois)
$registrations = $pdo->query("
    SELECT DATE_FORMAT(date_inscription, '%Y-%m') AS mois, COUNT(*) AS nb
    FROM utilisateurs
    WHERE date_inscription >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(date_inscription, '%Y-%m')
    ORDER BY mois ASC
")->fetchAll();

// Publicités performance
$adPerf = $pdo->query("
    SELECT titre, partenaire, position, clics, impressions,
           CASE WHEN impressions > 0 THEN ROUND(clics * 100.0 / impressions, 2) ELSE 0 END AS ctr
    FROM publicites WHERE statut = 'actif' ORDER BY clics DESC LIMIT 10
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><i class="fas fa-chart-bar text-accent"></i> Statistiques</h1>
            <div style="display:flex;gap:4px;">
                <a href="?periode=7" class="btn <?= $periode=='7'?'btn-primary':'btn-secondary' ?> btn-sm">7 jours</a>
                <a href="?periode=30" class="btn <?= $periode=='30'?'btn-primary':'btn-secondary' ?> btn-sm">30 jours</a>
                <a href="?periode=90" class="btn <?= $periode=='90'?'btn-primary':'btn-secondary' ?> btn-sm">90 jours</a>
            </div>
        </div>

        <!-- Graphique visites -->
        <div class="chart-container" style="margin-bottom:var(--spacing-xl);">
            <div class="chart-header">
                <h3 class="chart-title">Visites du site (<?= $periode ?> derniers jours)</h3>
            </div>
            <canvas id="visitsChart" height="100"></canvas>
        </div>

        <div class="grid grid-2" style="margin-bottom:var(--spacing-xl);">
            <!-- Articles les plus vus -->
            <div class="chart-container">
                <div class="chart-header"><h3 class="chart-title"><i class="fas fa-fire text-warning"></i> Articles les plus vus</h3></div>
                <?php foreach ($topArticles as $idx => $ta): ?>
                <div style="display:flex;align-items:center;gap:var(--spacing-md);padding:8px 0;<?= $idx < count($topArticles)-1 ? 'border-bottom:1px solid var(--border-color);' : '' ?>">
                    <span style="font-weight:800;color:var(--text-muted);width:24px;"><?= $idx+1 ?></span>
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:600;font-size:0.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= sanitize($ta['titre']) ?></div>
                        <span class="tag" style="background:<?= $ta['couleur'] ?>20;color:<?= $ta['couleur'] ?>;font-size:0.65rem;padding:1px 6px;"><?= sanitize($ta['rubrique_nom']) ?></span>
                    </div>
                    <span style="font-weight:700;color:var(--accent-primary);"><?= number_format($ta['vues']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Inscriptions par mois -->
            <div class="chart-container">
                <div class="chart-header"><h3 class="chart-title"><i class="fas fa-user-plus text-success"></i> Inscriptions mensuelles</h3></div>
                <canvas id="registrationsChart" height="200"></canvas>
            </div>
        </div>

        <!-- Activité par thématique -->
        <div class="chart-container" style="margin-bottom:var(--spacing-xl);">
            <div class="chart-header"><h3 class="chart-title"><i class="fas fa-th-large text-accent"></i> Activité par thématique</h3></div>
            <table class="data-table">
                <thead><tr><th>Thématique</th><th>Articles</th><th>Forums</th><th>Sujets</th><th>Messages</th><th>Activité totale</th></tr></thead>
                <tbody>
                    <?php foreach ($activityByTheme as $at): ?>
                    <tr>
                        <td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?= $at['couleur'] ?>;margin-right:8px;"></span><strong><?= sanitize($at['nom']) ?></strong></td>
                        <td><?= $at['articles'] ?></td>
                        <td><?= $at['forums'] ?></td>
                        <td><?= $at['sujets'] ?></td>
                        <td><?= $at['messages'] ?></td>
                        <td>
                            <?php $total = $at['articles'] + $at['sujets'] + $at['messages']; ?>
                            <div style="display:flex;align-items:center;gap:8px;">
                                <div style="flex:1;height:6px;background:var(--bg-secondary);border-radius:3px;overflow:hidden;">
                                    <div style="height:100%;width:<?= min(100, $total) ?>%;background:<?= $at['couleur'] ?>;border-radius:3px;"></div>
                                </div>
                                <span style="font-weight:700;font-size:0.85rem;"><?= $total ?></span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="grid grid-2" style="margin-bottom:var(--spacing-xl);">
            <!-- Participation forum -->
            <div class="chart-container">
                <div class="chart-header"><h3 class="chart-title"><i class="fas fa-trophy text-warning"></i> Participation au forum</h3></div>
                <?php foreach ($forumParticipation as $idx => $fp): ?>
                <div style="display:flex;align-items:center;gap:var(--spacing-sm);padding:6px 0;<?= $idx < count($forumParticipation)-1 ? 'border-bottom:1px solid var(--border-color);' : '' ?>">
                    <img src="<?= UPLOAD_URL ?>avatars/<?= sanitize($fp['avatar']) ?>" alt=""
                         onerror="this.src='<?= SITE_URL ?>/assets/img/default-avatar.svg'"
                         style="width:32px;height:32px;border-radius:50%;object-fit:cover;">
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:600;font-size:0.85rem;"><?= sanitize($fp['prenom'] . ' ' . $fp['nom']) ?></div>
                    </div>
                    <div style="display:flex;gap:var(--spacing-md);font-size:0.75rem;color:var(--text-muted);">
                        <span title="Sujets"><i class="fas fa-file-alt"></i> <?= $fp['sujets'] ?></span>
                        <span title="Réponses"><i class="fas fa-reply"></i> <?= $fp['reponses'] ?></span>
                        <span title="Commentaires"><i class="fas fa-comment"></i> <?= $fp['commentaires'] ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Performance publicités -->
            <div class="chart-container">
                <div class="chart-header"><h3 class="chart-title"><i class="fas fa-ad text-info"></i> Performance publicités</h3></div>
                <?php if (empty($adPerf)): ?>
                <p class="text-muted text-center" style="padding:var(--spacing-xl);">Aucune publicité active.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Publicité</th><th>Clics</th><th>Impressions</th><th>CTR</th></tr></thead>
                    <tbody>
                        <?php foreach ($adPerf as $ap): ?>
                        <tr>
                            <td style="font-size:0.85rem;"><strong><?= sanitize($ap['titre']) ?></strong><br><small class="text-muted"><?= sanitize($ap['partenaire']) ?></small></td>
                            <td><?= number_format($ap['clics']) ?></td>
                            <td><?= number_format($ap['impressions']) ?></td>
                            <td><span class="tag tag-<?= $ap['ctr'] > 2 ? 'success' : ($ap['ctr'] > 0.5 ? 'warning' : 'danger') ?>"><?= $ap['ctr'] ?>%</span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
new Chart(document.getElementById('visitsChart'), {
    type: 'bar',
    data: {
        labels: [<?= implode(',', array_map(function($v) { return '"' . date('d/m', strtotime($v['jour'])) . '"'; }, $visitsData)) ?>],
        datasets: [{
            label: 'Visites', data: [<?= implode(',', array_column($visitsData, 'nb')) ?>],
            backgroundColor: 'rgba(108,99,255,0.3)', borderColor: '#6C63FF', borderWidth: 1, borderRadius: 4
        }]
    },
    options: { responsive: true, plugins: { legend: { display: false } },
        scales: { x: { grid: { display: false }, ticks: { color: '#6B6B80' } }, y: { grid: { color: 'rgba(108,99,255,0.05)' }, ticks: { color: '#6B6B80' }, beginAtZero: true } }
    }
});

new Chart(document.getElementById('registrationsChart'), {
    type: 'bar',
    data: {
        labels: [<?= implode(',', array_map(function($r) { return '"' . date('M Y', strtotime($r['mois'] . '-01')) . '"'; }, $registrations)) ?>],
        datasets: [{
            label: 'Inscriptions', data: [<?= implode(',', array_column($registrations, 'nb')) ?>],
            backgroundColor: 'rgba(0,212,170,0.3)', borderColor: '#00D4AA', borderWidth: 1, borderRadius: 4
        }]
    },
    options: { responsive: true, plugins: { legend: { display: false } },
        scales: { x: { grid: { display: false }, ticks: { color: '#6B6B80' } }, y: { grid: { color: 'rgba(0,212,170,0.05)' }, ticks: { color: '#6B6B80' }, beginAtZero: true } }
    }
});
</script>
</body>
</html>
