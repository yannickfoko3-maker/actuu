<?php
/**
 * Admin - Gestion des publicités / partenaires
 */
require_once __DIR__ . '/../config.php';
if (!isAdmin()) { redirect(SITE_URL . '/connexion.php'); }

$currentAdmin = 'publicites';
$pageTitle = 'Publicités partenaires';

// Suppression
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM publicites WHERE id = ?")->execute([intval($_GET['delete'])]);
    setFlash('success', 'Publicité supprimée.');
    redirect(SITE_URL . '/admin/publicites.php');
}

// Ajout / Modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) { setFlash('error', 'Token invalide.'); redirect($_SERVER['REQUEST_URI']); }

    $id = intval($_POST['id'] ?? 0);
    $titre = trim($_POST['titre'] ?? '');
    $partenaire = trim($_POST['partenaire'] ?? '');
    $lien_url = trim($_POST['lien_url'] ?? '');
    $position = $_POST['position'] ?? 'sidebar';
    $priorite = intval($_POST['priorite'] ?? 0);
    $date_debut = $_POST['date_debut'] ?? date('Y-m-d');
    $date_fin = $_POST['date_fin'] ?? date('Y-m-d', strtotime('+30 days'));
    $statut = $_POST['statut'] ?? 'actif';

    $image = '';
    if ($id) {
        $existing = $pdo->prepare("SELECT image FROM publicites WHERE id = ?");
        $existing->execute([$id]);
        $image = $existing->fetchColumn();
    }

    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($_FILES['image'], 'publicites');
        if ($result['success']) $image = $result['filename'];
    }

    if (empty($titre) || empty($partenaire)) {
        setFlash('error', 'Le titre et le partenaire sont obligatoires.');
    } else {
        if ($id) {
            $pdo->prepare("UPDATE publicites SET titre=?,partenaire=?,image=?,lien_url=?,position=?,priorite=?,date_debut=?,date_fin=?,statut=? WHERE id=?")
                ->execute([$titre, $partenaire, $image, $lien_url, $position, $priorite, $date_debut, $date_fin, $statut, $id]);
            setFlash('success', 'Publicité mise à jour !');
        } else {
            $pdo->prepare("INSERT INTO publicites (titre,partenaire,image,lien_url,position,priorite,date_debut,date_fin,statut) VALUES (?,?,?,?,?,?,?,?,?)")
                ->execute([$titre, $partenaire, $image, $lien_url, $position, $priorite, $date_debut, $date_fin, $statut]);
            setFlash('success', 'Publicité ajoutée !');
        }
    }
    redirect(SITE_URL . '/admin/publicites.php');
}

// Édition
$editPub = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM publicites WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editPub = $stmt->fetch();
}

$publicites = $pdo->query("SELECT * FROM publicites ORDER BY date_creation DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publicités | <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="dashboard-header">
            <h1 class="dashboard-title"><i class="fas fa-ad text-accent"></i> Publicités partenaires</h1>
        </div>

        <?php $flash = getFlash(); if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>"><i class="fas fa-check-circle"></i> <?= $flash['message'] ?></div>
        <?php endif; ?>

        <div class="grid" style="grid-template-columns: 1fr 380px; gap: var(--spacing-xl);">
            <!-- Liste -->
            <div>
                <div class="chart-container" style="padding:0;overflow:hidden;">
                    <table class="data-table">
                        <thead>
                            <tr><th>Publicité</th><th>Partenaire</th><th>Position</th><th>Clics</th><th>Impressions</th><th>Période</th><th>Statut</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php if (empty($publicites)): ?>
                            <tr><td colspan="8" style="text-align:center;padding:var(--spacing-2xl);color:var(--text-muted);">Aucune publicité.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($publicites as $pub): ?>
                            <tr>
                                <td>
                                    <div style="display:flex;align-items:center;gap:8px;">
                                        <?php if ($pub['image']): ?>
                                        <img src="<?= UPLOAD_URL ?>publicites/<?= sanitize($pub['image']) ?>" alt="" style="width:40px;height:40px;border-radius:4px;object-fit:cover;">
                                        <?php endif; ?>
                                        <span style="font-weight:600;font-size:0.85rem;"><?= sanitize($pub['titre']) ?></span>
                                    </div>
                                </td>
                                <td style="font-size:0.85rem;"><?= sanitize($pub['partenaire']) ?></td>
                                <td><span class="tag tag-primary"><?= ucfirst($pub['position']) ?></span></td>
                                <td><?= number_format($pub['clics']) ?></td>
                                <td><?= number_format($pub['impressions']) ?></td>
                                <td style="font-size:0.78rem;color:var(--text-muted);"><?= date('d/m/y', strtotime($pub['date_debut'])) ?> - <?= date('d/m/y', strtotime($pub['date_fin'])) ?></td>
                                <td><span class="tag tag-<?= $pub['statut']==='actif'?'success':'warning' ?>"><?= ucfirst($pub['statut']) ?></span></td>
                                <td>
                                    <a href="?edit=<?= $pub['id'] ?>" class="btn btn-ghost btn-sm"><i class="fas fa-edit"></i></a>
                                    <a href="?delete=<?= $pub['id'] ?>" class="btn btn-ghost btn-sm" style="color:var(--danger);" onclick="return confirm('Supprimer ?');"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Formulaire -->
            <div>
                <div class="card" style="padding:var(--spacing-lg);">
                    <h3 style="font-weight:700;margin-bottom:var(--spacing-lg);font-size:0.95rem;">
                        <?= $editPub ? 'Modifier la publicité' : 'Ajouter une publicité' ?>
                    </h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <input type="hidden" name="id" value="<?= $editPub['id'] ?? 0 ?>">

                        <div class="form-group">
                            <label class="form-label">Titre *</label>
                            <input type="text" name="titre" class="form-control" value="<?= sanitize($editPub['titre'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Partenaire *</label>
                            <input type="text" name="partenaire" class="form-control" value="<?= sanitize($editPub['partenaire'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Lien URL</label>
                            <input type="url" name="lien_url" class="form-control" placeholder="https://..." value="<?= sanitize($editPub['lien_url'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Image / Bannière</label>
                            <?php if ($editPub && $editPub['image']): ?>
                            <img src="<?= UPLOAD_URL ?>publicites/<?= sanitize($editPub['image']) ?>" alt="" style="width:100%;border-radius:8px;margin-bottom:8px;max-height:120px;object-fit:cover;">
                            <?php endif; ?>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label class="form-label">Position</label>
                                <select name="position" class="form-control">
                                    <?php foreach (['sidebar','header','footer','inline','popup'] as $pos): ?>
                                    <option value="<?= $pos ?>" <?= ($editPub['position'] ?? 'sidebar') === $pos ? 'selected' : '' ?>><?= ucfirst($pos) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Priorité</label>
                                <input type="number" name="priorite" class="form-control" value="<?= $editPub['priorite'] ?? 0 ?>" min="0">
                            </div>
                        </div>
                        <div class="grid grid-2">
                            <div class="form-group">
                                <label class="form-label">Date début</label>
                                <input type="date" name="date_debut" class="form-control" value="<?= $editPub['date_debut'] ?? date('Y-m-d') ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Date fin</label>
                                <input type="date" name="date_fin" class="form-control" value="<?= $editPub['date_fin'] ?? date('Y-m-d', strtotime('+30 days')) ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Statut</label>
                            <select name="statut" class="form-control">
                                <option value="actif" <?= ($editPub['statut'] ?? 'actif') === 'actif' ? 'selected' : '' ?>>Actif</option>
                                <option value="inactif" <?= ($editPub['statut'] ?? '') === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?= $editPub ? 'Mettre à jour' : 'Ajouter' ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html>
